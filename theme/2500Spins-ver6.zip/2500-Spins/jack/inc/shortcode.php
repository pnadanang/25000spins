<?php

add_shortcode('find_rider', 'find_rider_func');

/**
 * Find Riders
 */
function find_rider_func ($atts) {
    ob_start();

    if (!check_attr('eventid', $atts)) return '';

    $event_ids = get_events($atts['eventid']);

    // TODO
    $riders = get_riders($event_ids); // get data right over here.
//    jack_pr($riders); // array of Object

    include_once THEME_URL_FOLDER.'/jack/inc/views/find_rider.php';
    return ob_get_clean();
}
// ----------------------------------------------------------------------
function get_data ($cate) {
    // rider =>
}

// leaderboard_widget_function
/**
 * Function save cache files.
 */
function get_riders ($event_ids) {
    $bene_id    = null;
    $size       = null;
    $mode       = 'Individual'; // team

    if (!empty($event_ids)) {
        $items = array();

        foreach ($event_ids as $event_id) {
            /**
             * - get cache files
             * - create function to update cache folders
             */
//            if (function_exists('get_featured')) {
//                die('get_featured');
//            }
            // TODO:
            // - Update Live code for featured.
//            $funders = get_featured($event_id, $bene_id, $size, $region);
            $funders = get_featured_test($event_id);
//            jack_pr($funders);
            if (!empty($funders)) {
                // array_push($items, $funders);
                $items = array_merge($items, $funders);
            }
        }

        return $items;
    }

    return array();

    // $top_individuals = get_featured_list($event_id,$bene_id,$size, $mode);
}

function get_riders_test() {
    $url = 'https://api.gofundraise.com.au/v1/leaderboards/fundraising?EventCampaignId=5014';
    $response = wp_remote_get($url);
    $body = wp_remote_retrieve_body($response);
    jack_pr($body);
}

function get_featured_test ($event_id) {
    $url = "https://api.gofundraise.com.au/v1/leaderboards/fundraising?EventCampaignId=$event_id";
    $response = wp_remote_get($url);
    if (is_wp_error($response)) return array();
    $body = json_decode($response['body']);
    if (!isset($body->Leaderboard)) return array();
    return $body->Leaderboard;
}
