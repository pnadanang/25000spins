<?php 
      function trip_finder_func($args) {
        ob_start();
        ?>
          <div id="search-page">
                <div class="">
                  <div class="top-search">
                    <div class="search_box">
                        <form role="search" method="get" class="" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                        <?php
                          printf( '<input type="search" class="et-search-field" placeholder="SEARCH" value="%2$s" name="s" title="%3$s" />',
                            esc_attr__( 'Search &hellip;', 'Divi' ),
                            get_search_query(),
                            esc_attr__( 'Search for:', 'Divi' )
                          );
                        ?>
                        <i class="fa fa-search search_icon" aria-hidden="true"></i>
                        </form>
                    </div>
                    <div class="type">
                      <ul>
                        <li><a href="#" class="active">TRIPS</a></li>
                        <li><a href="#" >RIDERS</a></li>
                        <li><a href="#" >TEAMS</a></li>
                        <li><a href="#" >PROJECTS</a></li>
                      </ul>
                    </div>
                  </div>
                  <div class="bottom-search">
                    <div class="filter-widget">
                      <div class="filter-widget-box">
                        <h4>REGIONS</h4>
                        <div class="filter-wrapper regions-filter">
                          <div class="input-filter">
                            <input type="checkbox" name=""><label>Europe</label>
                          </div>
                          <div class="input-filter">
                            <input type="checkbox" name=""><label>Europe</label>
                          </div>
                          <div class="input-filter">
                            <input type="checkbox" name=""><label>Europe</label>
                          </div>
                          <div class="input-filter">
                            <input type="checkbox" name=""><label>Europe</label>
                          </div>
                          <div class="input-filter">
                            <input type="checkbox" name=""><label>Europe</label>
                          </div>
                        </div>
                      </div>
                      <!-- -------------------------------------- -->
                      <div class="filter-widget-box">
                        <h4>DATE</h4>
                        <div class="filter-wrapper date-filter">
                          <p class="year">2018</p>
                          <span class="month">JAN</span>
                          <span class="month">JAN</span>
                          <span class="month">JAN</span>
                          <span class="month active">JAN</span>
                          <span class="month">JAN</span>
                          <span class="month">JAN</span>
                          <span class="month">JAN</span>
                          <span class="month active">JAN</span>
                          <span class="month">JAN</span>
                          <span class="month">JAN</span>
                        </div>
                      </div>
                      <!-- --------------------------------------- -->
                      <div class="filter-widget-box">
                        <h4>CYLCE TYPE</h4>
                        <div class="filter-wrapper regions-filter">
                          <div class="input-filter">
                            <input type="checkbox" name=""><label>ROAD</label>
                          </div>
                          <div class="input-filter">
                            <input type="checkbox" name=""><label>MOUNTAIN</label>
                          </div>
                        </div>
                      </div>
                      <!-- --------------------------------------- -->
                      <div class="filter-widget-box">
                        <h4>PRICE</h4>
                        <div class="filter-wrapper price-filter">
                          <div class="input-filter">
                                <input type="range" class="range-slider-price" min="100" max="1000"/>
                          </div>
                          <div class="value-get">
                            <div class="min_price">
                              <span>Min Price</span>
                              <span class="label_price">$ 100</span>
                            </div>
                            <div class="line-through">
                              <span>-----</span>
                            </div>
                            <div class="max_price">
                              <span>Max Price</span>
                              <span class="label_price">$ 1000</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="clear-all">
                        <span>Clear all filters</span>
                      </div>
                    </div>
                    <div class="result-data">
                        <div class="result-data-box">
                          <div class="result-left">
                            <span>SPAIN</span>
                            <p>ANDALUCIA</p>
                            <span>ACTIVE</span>
                            <div class="action-button">
                              <a href="#">REGISTER TO RIDE</a>
                              <a href="#">DONATE</a>
                            </div>
                          </div>
                          <div class="result-center" style="background: url(https://webjuicy.com/25000spins/wp-content/uploads/2018/11/cycling-training-road-biking.jpg);">
                          </div>
                          <div class="result-right">
                            <div class="dates">
                              <span class="title">DATES</span>
                              <p><i class="fa fa-calendar" aria-hidden="true"></i> 1 MARCH -10 JUNE</p>
                            </div>
                            <div class="from">
                              <span class="title">FROM</span>
                              <p><span class="currency">$399</span> PP</p>
                            </div>
                            <div class="description">
                              <span class="title">DESCRIPTIONS</span>
                              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore praesentium earum sed sunt neque nemo, culpa voluptatibus, esse quis repudiandae...</p>
                            </div>
                            <div class="ridetype">
                              <span class="title">RIDE TYPE</span>
                              <p>Active</p>
                              <span class="title">DURATION</span>
                              <p>6 days | 5 nights</p>
                              <span class="title">STYLE</span>
                              <p>Explore</p>
                            </div>
                          </div>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
        <?php

        $html = ob_get_clean();
        return $html;
    }
    add_shortcode('trip_finder', 'trip_finder_func');
    // =====================================================
    function blog_list_func($args) {
        ob_start();
        $args = array(
              'post_type'      => 'post',
              'posts_per_page' => -1,
              'order'          => 'ASC',
              'orderby'        => 'date'
           );
          $parent = new WP_Query( $args );
        ?>
              <div id="blog-section">
                  <div class="blog-wrapper">
                    <?php 
                      if ( $parent->have_posts() ) :
                      while ( $parent->have_posts() ) : $parent->the_post(); 
                    ?>
                      <div class="blog-wrapper-box">
                            <div class="featured-image">
                                <img src="<?php echo  get_the_post_thumbnail_url(get_the_ID(),'full'); ?>" alt="">
                            </div>
                            <div class="blog-details">
                                <h2 class="blog-title"><?php the_title(); ?></h2>
                                <p class="blog-date"><?php echo get_the_date( 'M / d / Y' ); ?></p>
                                <p class="blog-excerpt"><?php echo wp_trim_words( get_the_excerpt(), 30 ); ?><a href="<?php the_permalink(); ?>" class="blog-readmore">READ MORE <i class="fa fa-angle-right"></i></a></p>
                            </div>
                      </div>
                    <?php
                        endwhile;
                        endif; 
                        wp_reset_postdata(); 
                    ?>
                  </div>
              </div>
        <?php
        $html = ob_get_clean();
        return $html;
    }
    add_shortcode('blog_list', 'blog_list_func');
    // =====================================================
?>