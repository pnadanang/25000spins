<?php
    if(isset( $_GET['term'])){
        $termiput = $_GET['term'];
    }else{
      $termiput = 'trips';
    }
?>
<input type="hidden" id="termiput" value="<?php echo $termiput; ?>">
<div id="search-page">
    <div class="">
        <div class="bottom-search">
            <div class="left">
                <div class="left-box">
                <div class="filter-widget">
                    <div class="search_box">
                        <form role="search" method="get" class="" action="<?php echo esc_url(home_url('/')); ?>">
                            <?php
                            printf('<input type="search" class="et-search-field" placeholder="SEARCH" value="%2$s" name="s" title="%3$s" />',
                                esc_attr__('Search &hellip;', 'Divi'),
                                get_search_query(),
                                esc_attr__('Search for:', 'Divi')
                            );
                            ?>
                            <i class="fa fa-search search_icon" aria-hidden="true"></i>
                        </form>
                    </div>
                    <div class="filter-widget-box">
                        <span class="filter-widget-button">x</span>
                        <h4>REGIONS</h4>
                        <div class="filter-wrapper regions-filter">
                            <?php
                                $field = get_field_object('field_5c1e20bac4d30');
                                if( $field['choices'] ):
                                    foreach( $field['choices'] as $value => $label ): ?>
                                        <div class="input-filter option-set" data-group="regions">
                                            <label><input type="checkbox" name="" value=".<?php echo str_replace(" ","-",$label); ?>"><?php echo $label; ?></label>
                                        </div>
                                    <?php endforeach;
                                endif;
                            ?>
                        </div>
                    </div>
                    <!-- -------------------------------------- -->
                    <div class="filter-widget-box">
                        <h4>DATE</h4>
                        <div class="filter-wrapper date-filter option-set" data-group="date">
                            <?php
                                    $current_year   = get_current_year();
                                    $months         = get_short_month_names();
                            ?>
                            <p class="year"><?php if (isset($current_year)): echo $current_year; endif; ?></p>
                            <?php
                            if (isset($months) && !empty($months) && is_array($months)) {
                                // - get current month
                                $current_month = get_current_month();
                                foreach($months as $index => $month) {
                                    $month_value = $index + 1;
                                    $month_class = '';
                                    // - set color for current month and "active"
                                    if ($month_value == $current_month) {
    //                                  $month_class = 'active';
                                    }
                                    // - set color for previous months
                                    else if ($month_value < $current_month) {
                                        $month_class = 'previous';
                                    }
                                    // - set color for next months.
                                    else if ($month_value > $current_month) {
                                        $month_class = 'next';
                                    }
                                    ?>
                                    <!-- <span class="month" data-filter-value="<?php echo strtolower(date('F', strtotime($month))); ?>"><?= strtoupper($month) ?></span> -->
                                    <label><input type="checkbox" name="cylcetype" value=".<?php echo (date('F', strtotime($month))); ?>"><?php echo (date('M', strtotime($month))); ?></label>
                                    <?php
                                }
                            }
                            ?>
                        </div>
                    </div>
                    <!-- --------------------------------------- -->
                    <div class="filter-widget-box">
                        <h4>CYLCE TYPE</h4>
                        <div class="filter-wrapper cylcetype-filter">
                            <?php
                                $field = get_field_object('field_5c1e2394c4d32');
                                if( $field['choices'] ):
                                    foreach( $field['choices'] as $value => $label ): ?>
                                        <div class="input-filter option-set" data-group="cylcetype">
                                            <label><input type="checkbox" name="cylcetype" value=".<?php echo $label ?>"><?php echo $label ?></label>
                                        </div>
                                    <?php endforeach;
                                endif;
                            ?>
                            <!-- <div class="input-filter">
                                <label><input type="checkbox" name="cylcetype" value="Road">ROAD</label>
                            </div>
                            <div class="input-filter">
                                <label><input type="checkbox" name="cylcetype" value="Mountain">MOUNTAIN</label>
                            </div> -->
                        </div>
                    </div>
                    <!-- --------------------------------------- -->
                    <div class="filter-widget-box">
                        <h4>PRICE</h4>
                        <div class="filter-wrapper price-filter">
                            <div class="input-filter">
                                <input type="range" class="range-slider-price" min="100" max="1000"/>
                            </div>
                            <div class="value-get">
                                <div class="min_price">
                                    <span>Min Price</span>
                                    <span class="label_price">$ 100</span>
                                </div>
                                <div class="line-through">
                                    <span>-----</span>
                                </div>
                                <div class="max_price">
                                    <span>Max Price</span>
                                    <span class="label_price">$ 1000</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="clear-all">
                        <span>Clear all filters</span>
                    </div>
                </div>
                </div>
            </div>
            <!-- <div class="sort-timeline">
                <a href="#">NEW <i class="fa fa-long-arrow-up"></i></a>
                <a href="#">PRICE <i class="fa fa-long-arrow-up"></i></a>
            </div> -->
            <div class="right">

                <div class="type">
                    <ul>
                        <li><a href="#" class="navigation-fillter">Filter</a></li>
                        <?php
                            $page_url = get_page_link();
                            foreach ($terms as $term):
                                if($term->slug =='trips' && !isset( $_GET['term'])){
                                     $active = "active";
                                 }else
                                if($term->slug == $_GET['term']){
                                    $active = "active";
                                }else{
                                    $active = "";
                                }
                        ?>
                        <li><a href="<?php echo $page_url;?>?term=<?php echo $term->slug;?>" class="<?php echo $active ?>"><?php echo $term->name; ?></a></li>
                        <?php
                            endforeach;

                        ?>
                    </ul>
                </div>
                <div class="result-data">
                    <?php
                        class TotalFilter{
                            function run(){
                                $this->regions();
                                $this->dates();
                                $this->cycle_type();
                                $this->prices();
                            }
                            function regions(){
                                $regions = get_field('regions');
                               if( $regions ):
                                    foreach( $regions as $region ):
                                        echo str_replace(" ","-",$region['label']);
                                        echo " ";
                                    endforeach;
                                endif;
                            }
                            function dates(){
                                    $date = get_field('time_event');
                                    
                                    $date_from = $date['start_date'];
                                    $date_from_num = date('n', strtotime($date_from));
                                    // $date_from = strtolower(date('F', strtotime($date_from)));

                                    $date_to = $date['end_date'];
                                    $date_to_num = date('n', strtotime($date_to));
                                    // $date_to = date('m', strtotime($date_to));

                                    for ($i=$date_from_num; $i <= $date_to_num; $i++) { 
                                    	echo date('F', mktime(0, 0, 0, $i, 10));
                                    	echo " ";
                                    }
                                    
                            }
                            function cycle_type(){
                                    $cycle_type = get_field('cycle_type');
                                   if( $cycle_type ):
                                        foreach( $cycle_type as $cycle_types ):
                                            echo str_replace(" ","-",$cycle_types['label']);
                                            echo " ";
                                        endforeach;
                                    endif;
                            }
                            function prices(){
                                    echo $prices = get_field('price');
                            }
                        }
                        $totalFilter = new TotalFilter;

                        if($query->have_posts())
                            while ($query->have_posts()) :
                                $query->the_post();
                                $fields = get_fields();
                                $the_id = get_the_ID();
                                $the_title = get_the_title();
                                $regionz = get_field('regions');
                                $re = array();
                                foreach($regionz as $region){
                                   $re[] =  $region["label"];
                                }
                                //var_dump($regionz); die();
                    ?>
                    <div class="item result-data-box <?php $totalFilter->run(); ?>" data-price="<?php $totalFilter->prices() ?>">
                        <div class="result-left" style="cursor: pointer;">
                            <span><?php echo implode(",",$re);?></span>
                            <p><?php 
                            if(strpos(strtolower($the_title), "coromandel classic") !== false){ ?>
                               <a href="http://25000spins.gofundraise.com.au/"><?php the_title(); ?></a>
                            <?php }else{ ?>
                                <?php the_title(); ?>
                            <?php } ?>
                            </p>
                            <span>ACTIVE</span>
                            <div class="action-button">
                               <?php 
                            if(strpos(strtolower($the_title), "coromandel classic") !== false){ ?>
                                <a id="register-to-ride" data-id="sub-btn-nav-<?php echo $the_id;?>" href="http://25000spinsau.gofundraise.com.au/cms/registration">REGISTER TO RIDE</a>
                                <a href="https://25000spins.gofundraise.com.au/pages/search">DONATE</a>
                            <?php }else{ ?>
                                <a id="register-to-ride" data-id="sub-btn-nav-<?php echo $the_id;?>" href="http://25000spins.gofundraise.com.au/">REGISTER TO RIDE</a>
                                <a href="http://25000spins.gofundraise.com.au/">DONATE</a>
                            <?php } ?>   

                            </div>
                            <ul id="sub-btn-nav-<?php echo $the_id;?>" class="sub-btn-nav">
                                    <li><span class="sub-title">Where are you from?</span></li>
                                    <li><a href="#">Australia</a></li>
                                    <li><a href="#">New Zealand</a></li>
                                    <li><a href="#">United States</a></li>
                                    <li><a href="#">Others</a></li>
                                </ul>
                        </div>
                        <div class="result-center"
                             style="background: url(<?php the_post_thumbnail_url( $size = 'post-thumbnail' ) ?>);">
                        </div>
                        <div class="result-right">
                            <div class="dates">
                                <span class="title">DATES</span>
                                <p><i class="fa fa-calendar" aria-hidden="true"></i> <?php echo date("j F", strtotime($fields['time_event']['start_date'])).' - '.date("j F", strtotime($fields['time_event']['end_date'])); ?></p>
                            </div>
                            <div class="from">
                                <span class="title">FROM</span>
                                <p><span class="currency">$<?php echo $fields['price']; ?></span> PP</p>
                            </div>
                            <div class="description">
                                <span class="title">DESCRIPTIONS</span>
                              <!--   <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore praesentium earum
                                    sed sunt neque nemo, culpa voluptatibus, esse quis repudiandae...</p> -->
                                    <?php the_excerpt(); ?>
                            </div>
                            <div class="ridetype">
                                <span class="title">RIDE TYPE</span>
                                <p><?php echo $fields['rider_type']; ?></p>
                                <span class="title">DURATION</span>
                                <p><?php echo $fields['duration']; ?></p>
                                <span class="title">STYLE</span>
                                <p><?php echo $fields['style']; ?></p>
                            </div>
                        </div>
                    </div><!-- end item -->
                    <?php //end while
                        endwhile;
                    ?>
                    <div class="pagination">
                    <?php
                        echo paginate_links( array(
                            'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
                            'total'        => $query->max_num_pages,
                            'current'      => max( 1, get_query_var( 'paged' ) ),
                            'format'       => '?paged=%#%',
                            'show_all'     => false,
                            'type'         => 'plain',
                            'end_size'     => 2,
                            'mid_size'     => 1,
                            'prev_next'    => false,
                            //'prev_text'    => sprintf( '<i></i> %1$s', __( 'Newer Posts', 'text-domain' ) ),
                            //'next_text'    => sprintf( '%1$s <i></i>', __( 'Older Posts', 'text-domain' ) ),
                            'add_args'     => false,
                            'add_fragment' => '',
                        ) );
                    ?>
                    </div>
                </div><!-- end wrap -->
            </div>
        </div>
    </div>
</div>
