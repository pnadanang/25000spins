<?php 
function wpcodex_add_excerpt_support_for_our_guides() {
   add_post_type_support( 'our_guides', 'excerpt' );
}
add_action( 'init', 'wpcodex_add_excerpt_support_for_our_guides' );

add_shortcode('meet_our_guides', 'meet_our_guides_func');
function meet_our_guides_func()
{	
	$args = array(
	  'posts_per_page' => 6,
	  'post_type'   => 'our_guides'
	);
    $our_guides = new WP_Query( $args );
    //var_dump($our_guides); die();
    ob_start();
    if ( $our_guides->have_posts() ) {
    	echo '<ul class="meet-our-guides-list">';
        while ($our_guides->have_posts()) {

            $our_guides->the_post();

            include(THEME_URL_FOLDER.'/inc/views/meet_our_guides.php');

        }
        echo '</ul>';
    }

    return ob_get_clean();
}