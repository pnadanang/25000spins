<?php
if($query->have_posts())
    while ($query->have_posts()) :
        $query->the_post();
        $fields = get_fields();
?>
<div class="result-data-box">
    <div class="result-left">
        <span>SPAIN</span>
        <p><?php the_title(); ?></p>
        <span>ACTIVE</span>
        <div class="action-button">
            <a href="#">REGISTER TO RIDE</a>
            <a href="#">DONATE</a>
        </div>
    </div>
    <div class="result-center"
         style="background: url(<?php the_post_thumbnail_url( $size = 'post-thumbnail' ) ?>);">
    </div>
    <div class="result-right">
        <div class="dates">
            <span class="title">DATES</span>
            <p><i class="fa fa-calendar" aria-hidden="true"></i> <?php echo date("j F", strtotime($fields['time_event']['start_date'])).' - '.date("j F", strtotime($fields['time_event']['end_date'])); ?></p>
        </div>
        <div class="from">
            <span class="title">FROM</span>
            <p><span class="currency">$<?php echo $fields['price']; ?></span> PP</p>
        </div>
        <div class="description">
            <span class="title">DESCRIPTIONS</span>
          <!--   <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore praesentium earum
                sed sunt neque nemo, culpa voluptatibus, esse quis repudiandae...</p> -->
                <?php the_excerpt(); ?>
        </div>
        <div class="ridetype">
            <span class="title">RIDE TYPE</span>
            <p><?php echo $fields['rider_type']; ?></p>
            <span class="title">DURATION</span>
            <p><?php echo $fields['duration']; ?></p>
            <span class="title">STYLE</span>
            <p><?php echo $fields['style']; ?></p>
        </div>
    </div>
</div><!-- end item -->
<?php //end while
    endwhile;

  	