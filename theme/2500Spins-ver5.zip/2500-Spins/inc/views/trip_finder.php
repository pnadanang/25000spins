<?php 
    if(isset( $_GET['term'])){
        $termiput = $_GET['term'];
    }else{
      $termiput = 'trips';
    }
?>
<input type="hidden" id="termiput" value="<?php echo $termiput; ?>">
<div id="search-page">
    <div class="">
        <div class="top-search">
            <div class="search_box">
                <form role="search" method="get" class="" action="<?php echo esc_url(home_url('/')); ?>">
                    <?php
                    printf('<input type="search" class="et-search-field" placeholder="SEARCH" value="%2$s" name="s" title="%3$s" />',
                        esc_attr__('Search &hellip;', 'Divi'),
                        get_search_query(),
                        esc_attr__('Search for:', 'Divi')
                    );
                    ?>
                    <i class="fa fa-search search_icon" aria-hidden="true"></i>
                </form>
            </div>
            <div class="type">
                <ul>
                    <?php 
                        $page_url = get_page_link();
                        foreach ($terms as $term):
                            if($term->slug =='trips' && !isset( $_GET['term'])){
                                 $active = "active";
                             }else
                            if($term->slug == $_GET['term']){
                                $active = "active";
                            }else{
                                $active = "";
                            }
                    ?>
                    <li><a href="<?php echo $page_url;?>?term=<?php echo $term->slug;?>" class="<?php echo $active ?>"><?php echo $term->name; ?></a></li>
                    <?php 
                        endforeach;

                    ?>
                </ul>
            </div>
        </div>
        <div class="bottom-search">
            <div class="filter-widget">
                <div class="filter-widget-box">
                    <h4>REGIONS</h4>
                    <div class="filter-wrapper regions-filter">
                        <?php
                            $field = get_field_object('field_5c1e20bac4d30');
                            if( $field['choices'] ):
                                foreach( $field['choices'] as $value => $label ): ?>
                                    <div class="input-filter">
                                        <label><input type="checkbox" name="" value="<?php echo $label; ?>"><?php echo $label; ?></label>
                                    </div>
                                <?php endforeach;
                            endif;
                        ?>
                        <!-- <div class="input-filter">
                            <label><input type="checkbox" name="" value="Europe">Europe</label>
                        </div>
                        <div class="input-filter">
                            <label><input type="checkbox" name="" value="Noth America">Noth America</label>
                        </div>
                        <div class="input-filter">
                            <label><input type="checkbox" name="" value="Australia">Australia</label>
                        </div>
                        <div class="input-filter">
                            <label><input type="checkbox" name="" value="New Zealand">New Zealand</label>
                        </div>
                        <div class="input-filter">
                            <label><input type="checkbox" name="" value="Asia">Asia</label>
                        </div> -->
                    </div>
                </div>
                <!-- -------------------------------------- -->
                <div class="filter-widget-box">
                    <h4>DATE</h4>
                    <div class="filter-wrapper date-filter">
                        <p class="year">2018</p>
                        <span class="month">JAN</span>
                        <span class="month">JAN</span>
                        <span class="month">JAN</span>
                        <span class="month active">JAN</span>
                        <span class="month">JAN</span>
                        <span class="month">JAN</span>
                        <span class="month">JAN</span>
                        <span class="month active">JAN</span>
                        <span class="month">JAN</span>
                        <span class="month">JAN</span>
                    </div>
                </div>
                <!-- --------------------------------------- -->
                <div class="filter-widget-box">
                    <h4>CYLCE TYPE</h4>
                    <div class="filter-wrapper cylcetype-filter">
                        <?php
                            $field = get_field_object('field_5c1e2394c4d32');
                            if( $field['choices'] ):
                                foreach( $field['choices'] as $value => $label ): ?>
                                    <div class="input-filter">
                                        <label><input type="checkbox" name="cylcetype" value="<?php echo $label ?>"><?php echo $label ?></label>
                                    </div>
                                <?php endforeach;
                            endif;
                        ?>
                        <!-- <div class="input-filter">
                            <label><input type="checkbox" name="cylcetype" value="Road">ROAD</label>
                        </div>
                        <div class="input-filter">
                            <label><input type="checkbox" name="cylcetype" value="Mountain">MOUNTAIN</label>
                        </div> -->
                    </div>
                </div>
                <!-- --------------------------------------- -->
                <div class="filter-widget-box">
                    <h4>PRICE</h4>
                    <div class="filter-wrapper price-filter">
                        <div class="input-filter">
                            <input type="range" class="range-slider-price" min="100" max="1000"/>
                        </div>
                        <div class="value-get">
                            <div class="min_price">
                                <span>Min Price</span>
                                <span class="label_price">$ 100</span>
                            </div>
                            <div class="line-through">
                                <span>-----</span>
                            </div>
                            <div class="max_price">
                                <span>Max Price</span>
                                <span class="label_price">$ 1000</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clear-all">
                    <span>Clear all filters</span>
                </div>
            </div>
            <!-- <div class="sort-timeline">
                <a href="#">NEW <i class="fa fa-long-arrow-up"></i></a>
                <a href="#">PRICE <i class="fa fa-long-arrow-up"></i></a>
            </div> -->
            <div class="result-data">
                <?php
                if($query->have_posts())
                    while ($query->have_posts()) :
                        $query->the_post();
                        $fields = get_fields();
                ?>
                <div class="result-data-box">
                    <div class="result-left">
                        <span>SPAIN</span>
                        <p><?php the_title(); ?></p>
                        <span>ACTIVE</span>
                        <div class="action-button">
                            <a href="#">REGISTER TO RIDE</a>
                            <a href="#">DONATE</a>
                        </div>
                    </div>
                    <div class="result-center"
                         style="background: url(<?php the_post_thumbnail_url( $size = 'post-thumbnail' ) ?>);">
                    </div>
                    <div class="result-right">
                        <div class="dates">
                            <span class="title">DATES</span>
                            <p><i class="fa fa-calendar" aria-hidden="true"></i> <?php echo date("j F", strtotime($fields['time_event']['start_date'])).' - '.date("j F", strtotime($fields['time_event']['end_date'])); ?></p>
                        </div>
                        <div class="from">
                            <span class="title">FROM</span>
                            <p><span class="currency">$<?php echo $fields['price']; ?></span> PP</p>
                        </div>
                        <div class="description">
                            <span class="title">DESCRIPTIONS</span>
                          <!--   <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore praesentium earum
                                sed sunt neque nemo, culpa voluptatibus, esse quis repudiandae...</p> -->
                                <?php the_excerpt(); ?>
                        </div>
                        <div class="ridetype">
                            <span class="title">RIDE TYPE</span>
                            <p><?php echo $fields['rider_type']; ?></p>
                            <span class="title">DURATION</span>
                            <p><?php echo $fields['duration']; ?></p>
                            <span class="title">STYLE</span>
                            <p><?php echo $fields['style']; ?></p>
                        </div>
                    </div>
                </div><!-- end item -->
                <?php //end while
                    endwhile;
                ?>
                <div class="pagination">
                <?php 
                    echo paginate_links( array(
                        'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
                        'total'        => $query->max_num_pages,
                        'current'      => max( 1, get_query_var( 'paged' ) ),
                        'format'       => '?paged=%#%',
                        'show_all'     => false,
                        'type'         => 'plain',
                        'end_size'     => 2,
                        'mid_size'     => 1,
                        'prev_next'    => false,
                        //'prev_text'    => sprintf( '<i></i> %1$s', __( 'Newer Posts', 'text-domain' ) ),
                        //'next_text'    => sprintf( '%1$s <i></i>', __( 'Older Posts', 'text-domain' ) ),
                        'add_args'     => false,
                        'add_fragment' => '',
                    ) );
                ?>
                </div>
            </div><!-- end wrap -->
        </div>
    </div>
</div>