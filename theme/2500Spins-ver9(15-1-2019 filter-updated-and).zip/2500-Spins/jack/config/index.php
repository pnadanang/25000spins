<?php

/**
 * Mode
 * 1. Individual
 * 2. team
 */

define( 'JACK_DIR', get_stylesheet_directory() . '/jack' );
define( 'THEME_PATH', get_stylesheet_directory_uri() );
// $cachetime = 18000;
define( 'CACHE_TIME', 18000 ); // seconds

function get_short_month_names(){
	return ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sept','Oct','Nov','Dec'];
}

// return "value"
function get_cycle_types () {
	return array('road', 'mountain');
}
