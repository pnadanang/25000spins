<?php

function jack_pr($data) {
    if (is_array($data) || is_object($data)) {
        echo '<pre>';
        print_r($data);
        echo '</pre>';
    } else {
        var_dump($data);
    }
    die();
}

function get_current_month () {
	return (int) date('m');
}

function get_short_month_name ($timestamp) {
	return (int) date('m', $timestamp);
}

function get_current_year () {
	return (int) date('Y');
}

function getTimeStamp ($dateTimeString) {
	$date_time = new DateTime($dateTimeString);
	return strtotime( $date_time->format('Y-m-d H:i:s') );
}

function get_random_date_in_year () {
	$new_year = getTimeStamp('2018-01-01');
	$end_year = getTimeStamp('2018-12-31');
	$random_timestamp = rand($new_year, $end_year);
	return $random_timestamp;
}

function get_random_month_from_timestamp($type = 'text') {
	$timestamp = get_random_date_in_year();
	if ($type == 'text') $type = 'M';
	else if ($type == 'number') $type = 'm';
	return date($type, $timestamp);
}

function check_current_page ($page_slug) {
	global $post;
	$post_slug=$post->post_name;
	return $post_slug == $page_slug;
}
