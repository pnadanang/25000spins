jQuery(function ($) {
    // =============================
    setInterval(function () {
        // =============================
        var maxHeight_slider = 0;
        var video_box = jQuery('.video-box-homepage').parent('.owl-item');
        $(video_box).each(function () {
            if ($(this).height() > maxHeight_slider) {
                maxHeight_slider = $(this).height();
            }
        });
        $("#slider_home .big .owl-item").height(maxHeight_slider);
        // ====================================
        // $("#slider_home .big .owl-item").css('max-height','400px');
        // $("#slider_home .et_pb_video_box video").css('height','600px!important');
        // ====================================
    }, 100);
// ========================================
    setTimeout(function () {
        $('.full_width_3_col.center span.number').each(function () {
            $(this).prop('Counter', 0).animate({
                Counter: $(this).html()
            }, {
                duration: 6000,
                easing: 'swing',
                step: function (now) {
                    $(this).text(Math.ceil(now).toLocaleString('en'));
                }
            });
        });
    }, 2000);
// ========================================
    var $container;
    var priceFilter = { 'min':100, 'max': 1000 };
    var filters = [];
    var $grid;

    $container = $('.result-data');

    $grid = $container.isotope({
        itemSelector: '.result-data-box',
        filter : function () {
            var $this = $(this);
            var price = $this.data('price');
            var price_attr = $this.attr('data-price');

            var isInPriceRange = (priceFilter.min <= price && priceFilter.max >= price);
            console.log(isInPriceRange);
            return isInPriceRange;
        }
    });
    // do stuff when checkbox change
    $('.filter-widget').on( 'change', function( jQEvent ) {
        
        var $checkbox = $( jQEvent.target );
        //console.log($checkbox)
        //console.log(filters);
        //console.log(filters);
        var comboFilter = selectAllCheckbox( );
        //console.log(comboFilter);
        $container.isotope({
            itemSelector: '.result-data-box',
            filter : function ( ) {
                console.log(comboFilter);
                var $this = $(this);
                var price = $this.data('price');
                var price_attr = $this.attr('data-price');
                var hasFilter = false;

                var hasFilterPrice = (priceFilter.min <= price && priceFilter.max >= price);
                if(hasFilterPrice){
                    for(let i = 0; i < comboFilter.length; i++) {
                        if($this.hasClass(comboFilter[i].replace(".",""))){
                           hasFilter = true; 
                           break;
                        } else {
                            hasFilter = false; 
                        }
                    }
                    return hasFilter;
                } else return false;
            }
        });
    });
    // functino function getComboFilter( filters ){

    // }

    function getComboFilter( filters ) {
      var i = 0;
      var comboFilters = [];
      var message = [];

      for ( var prop in filters ) {
        message.push( filters[ prop ].join(' ') );
        var filterGroup = filters[ prop ];
        // skip to next filter group if it doesn't have any values
        if ( !filterGroup.length ) {
          continue;
        }
        if ( i === 0 ) {
          // copy to new array
          comboFilters = filterGroup.slice(0);
        } else {
          var filterSelectors = [];
          // copy to fresh array
          var groupCombo = comboFilters.slice(0); // [ A, B ]
          // merge filter Groups
          for (var k=0, len3 = filterGroup.length; k < len3; k++) {
            for (var j=0, len2 = groupCombo.length; j < len2; j++) {
              filterSelectors.push( groupCombo[j] + filterGroup[k] ); // [ 1, 2 ]
            }

          }
          // apply filter selectors to combo filters for next group
          comboFilters = filterSelectors;
        }
        i++;
      }

      //var comboFilter = comboFilters.join(', ');
      comboFilter = comboFilters;
      return comboFilter;
    }
    function selectAllCheckbox(){
        var filters = [];
        $('.filter-widget label input[type=checkbox]:checked').each(function (index, value) {
            var $value = $(this).val();
            filters.push($value);
        });
        return filters;
    }
    function manageCheckbox( $checkbox ) {
      var checkbox = $checkbox[0];

      var group = $checkbox.parents('.option-set').attr('data-group');
      // create array for filter group, if not there yet
      var filterGroup = filters[ group ];
      if ( !filterGroup ) {
        filterGroup = filters[ group ] = [];
      }

      var isAll = $checkbox.hasClass('all');
      // reset filter group if the all box was checked
      if ( isAll ) {
        delete filters[ group ];
        if ( !checkbox.checked ) {
          checkbox.checked = 'checked';
        }
      }
      // index of
      var index = $.inArray( checkbox.value, filterGroup );

      if ( checkbox.checked ) {
        var selector = isAll ? 'input' : 'input.all';
        $checkbox.siblings( selector ).removeAttr('checked');


        if ( !isAll && index === -1 ) {
          // add filter to group
          filters[ group ].push( checkbox.value );
        }

      } else if ( !isAll ) {
        // remove filter from group
        filters[ group ].splice( index, 1 );
        // if unchecked the last box, check the all
        if ( !$checkbox.siblings('[checked]').length ) {
          $checkbox.siblings('input.all').attr('checked', 'checked');
        }
      }
    }
    // ------------------------------------------------------------

// ===============================
// console.log(123);
    $('.filter-widget-box h4').click(function () {
        $(this).next('.filter-wrapper').slideToggle(500);
        $(this).toggleClass('close');
    });
    // ==============================
    $(".filter-widget-box input[type='checkbox']").click(function () {
        if ($(this).is(':checked')) {
            $(this).parent('label').addClass('checked');
        } else {
            $(this).parent('label').removeClass('checked');
        }
    });
    // ===================================
    var minValue = $('.range-slider-price[type="range"]').prop('min');
    var maxValue = $('.range-slider-price[type="range"]').prop('max');
    $(".range-slider-price").ionRangeSlider({
        skin: "round",
        type: "double",
        grid: false,
        min: minValue,
        max: maxValue,
        from: minValue,
        to: maxValue,
        onFinish: function (data) {
            var from = data.from;
            // console.log(from)
            var to = data.to;
            // console.log(to)
            priceFilter.min = from || 0;
            priceFilter.max = to || 0;
            // console.log(priceFilter)
             //console.log($grid)
            //$grid.isotope();
            var comboFilter = selectAllCheckbox( );
            //console.log(comboFilter);
            $container.isotope({
                itemSelector: '.result-data-box',
                filter : function ( ) {
                    console.log(comboFilter);
                    var $this = $(this);
                    var price = $this.data('price');
                    var price_attr = $this.attr('data-price');
                    var hasFilter = false;

                    var hasFilterPrice = (priceFilter.min <= price && priceFilter.max >= price);
                    if(hasFilterPrice){
                        for(let i = 0; i < comboFilter.length; i++) {
                            if($this.hasClass(comboFilter[i].replace(".",""))){
                               hasFilter = true; 
                               break;
                            } else {
                                hasFilter = false; 
                            }
                        }
                        return hasFilter;
                    } else return false;
                }
            });
            console.log('udpate grid isotope')
        },
        // prefix: "$",
    });
    $(".range-slider-price").on("change", function () {
        var $inp = $(this);
        // var v = $inp.prop("value");     // input value in format FROM;TO
        var from = $inp.data("from");   // input data-from attribute
        var to = $inp.data("to");       // input data-to attribute
        $('.min_price span.label_price').text('$ ' + from);
        $('.max_price span.label_price').text('$ ' + to);
        // console.log(v, from, to);       // all values
        // console.log(from, to);
        // var price = [];
        // price.push(from);
        // price.push(to);
        // requestdata.price = price;
        // console.log(requestdata);
        // ajax_request();
    });
// ============================================================
    $('#menu_responsive ul#menu-primary-menu > li.menu-item-has-children > a').click(function (e) {
        $(this).next('ul.sub-menu').slideToggle();
        $(this).parent('li').toggleClass('open-child');
        e.preventDefault();
    });
    $('#menu_responsive ul#menu-secondary-menu > li.menu-item-has-children > a').click(function (e) {
        $(this).next('ul.sub-menu').slideToggle();
        $(this).parent('li').toggleClass('open-child');
        e.preventDefault();
    });
    $('ul li.search-items-icon a').click(function (e) {
        $('.form-box').slideToggle(300);
        $('.search_responsive_box').slideToggle(300);
        e.preventDefault();
    });
    // $('body').click(function (e) {
    //     $('.search_responsive_box').hide(300);
    //     console.log('hide');
    // });
    $('.form-box .close-form').click(function (e) {
        $('.form-box').hide(200);
        e.preventDefault();
    });
    $('#search_responsive_bar i.fa-search').click(function (e) {
        $('.search_responsive_box').slideToggle(300);
        e.preventDefault();
    });
// ================REMOVE $ SPECIAL CHARACTER========================
	function numberWithCommas(x) {
	    return x.toString().replace(/\B(?=(?:\d{3})+(?!\d))/g, ",");
	}
    var string = $('.find-adventure span.raise-so-far-donate-count').html();
    var string_change = '';
    if (string)
        string_change = string.replace("$", "").replace(",", "");
    	string_change = Math.ceil(string_change);
    v_pound = numberWithCommas(string_change);
            // console.log(v_pound);
    $('.find-adventure span.raise-so-far-donate-count').html(v_pound);
// ================REMOVE , and . SPECIAL CHARACTER AND ANIMATION NUMBER========================
    var string_2 = $('.full_width_3_col.center span.raise-so-far-donate-count').html();
    var string_change_2 = string_2 ? string_2.replace(',', '').replace('$', '') : "";
    var string_change_2 = Math.ceil(string_change_2)
    $('.full_width_3_col.center span.raise-so-far-donate-count').html(string_change_2);
    $('.full_width_3_col.center span.raise-so-far-donate-count').each(function () {
        $(this).prop('Counter', 0).animate({
            Counter: $(this).html()
        }, {
            duration: 8000,
            easing: 'swing',
            step: function (now) {
                $(this).text(Math.ceil(now).toLocaleString('en'));
            }
        });
    });
// ========================================
    $('#menu_responsive_bar i').click(function () {
        $('#menu_responsive').slideToggle(500);
    });
// console.log(1);
    window.onscroll = function () {
        myFunction()
    };
    var header = document.getElementById("scroll-nav"),
        sticky = header.offsetTop,
        top_menu = $('#top_menu'),
        logo_container = top_menu.children('.logo_container'),
        main_menu_wrapper = $('#main_menu_wrapper'),
        primary_menu = main_menu_wrapper.find('.primary_menu');

    function myFunction() {
        var logo_width = logo_container.width(),
            menu_height = main_menu_wrapper.height();
        if (window.pageYOffset > sticky) {
            header.classList.add("fixedheader");
            // logo_container.css({
            //     'height': menu_height,
            //     'width': logo_width
            // });
            // primary_menu.css('padding-left', logo_width);
        } else {
            header.classList.remove("fixedheader");
            // logo_container.css({'height': ''});
            // primary_menu.css('padding-left', '');
        }
    }
    // ===========================================
    $('.social_share a').click(function(event){
    	event.preventDefault();
    	link = $(this).attr('href');
    	console.log(link);
    	if (link)  
		window.open(
		  	link,
		  	'pop',
		  	"height=590,width=450,toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=auto,resizable=yes,copyhistory=no"
		  	); 
	});
	// ===========================================
});

