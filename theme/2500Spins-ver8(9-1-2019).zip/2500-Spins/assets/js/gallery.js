jQuery(document).ready(function() {
    //
    // Gallery & Staff/Guides Page
    //

    // Initialize Masonry
    if (jQuery('.item-masonry').length > 0) {
        jQuery('#content').imagesLoaded(function() {
            jQuery('#content').masonry({
                columnWidth: 270,
                itemSelector: '.item-masonry',
                isFitWidth: true,
                singleMode: false, //expanded addition
                resizeable: true, //expanded addition
                // isAnimated: !Modernizr.csstransitions
            });
        });
    }

    // Masonry Expanded
    jQuery(document).on('click', '.open-close', function() {
        if (jQuery(this).parent().is('.expanded')) {
            restoreBoxes();
        } else {
            jQuery(this).parent()
                // save original box size
                .data('size', [jQuery(this).parent().width(), jQuery(this).parent().height()])
                .animate({
                    width: '100%',
                    height: 560
                }, function() {
                    jQuery('#content').masonry();
                });
            restoreBoxes();
            jQuery(this).parent().addClass('expanded');
        }

        function restoreBoxes() {
            // stop videos
            jQuery('.item-masonry.type-video.expanded .player').each(function() {
                this.contentWindow.postMessage('{"event":"command","func":"' + 'stopVideo' + '","args":""}', '*')
            });

            var len = jQuery('.expanded').length - 1;
            jQuery('.expanded').each(function(i) {
                var box = jQuery(this).data('size');
                jQuery(this).animate({
                        width: (box[0] || 100),
                        height: (box[1] || 'auto'),
                    }, function() {
                        if (i >= len) {
                            jQuery('#content').masonry();
                        }
                    })
                    .removeClass('expanded');
            })
        }
    });

    jQuery('.item-masonry').click(function() {
        setTimeout(function() {
            jQuery('body,html').animate({ scrollTop: jQuery('.item-masonry.expanded').offset().top - 105 }, 'slow');
        }, 1200);
    });

    // Youtube close on Click
    jQuery('.item-masonry.type-video .open-close').click(function() {
        var video = jQuery(this).siblings('.feature').children('.player').attr('src');
        jQuery(this).siblings('.feature').children('.player').attr('src', '');
        jQuery(this).siblings('.feature').children('.player').attr('src', video);
    });
    
    jQuery('.nav.nav-tabs > li').click(function() {
        jQuery('.row.gallerytop').slideUp(500, 'linear', function() {
            jQuery('.row.gallerytop').addClass('fade hide');
        });
    });
    jQuery('#regions-tabs > li > a').click(function(e) {
        e.preventDefault();
        var $this = jQuery(this);
        var tabId = $this.attr("href");
        jQuery('#regions-tabs > li > a').removeClass("active");
        $this.addClass("active");
        jQuery("#country-tabs .tab-pane").removeClass("active");
        jQuery("#country-tabs .tab-pane"+tabId).addClass("active");
    });
    jQuery(function(jQuery) {
        var page = 1;
        var loading = true;
        var jQuerywindow = jQuery(window);
        var jQuerycontent = jQuery("#content");
        // Gallery specific
        var load_gallery = function() {
            var regions = [];
            jQuery('.country-tabs input:checked').each(function() {
                var addThis = jQuery(this).attr('value');
                regions += addThis + ',';
            });

            var mediatypes = jQuery('#media_type').attr('value');

            var allArgs = regions;

            var theArgs = allArgs.split(',');


            jQuery('.breadcrumbs > .btn-xs:not(#reset)').remove();

            jQuery.each(theArgs, function() {

                if (this != '' && !jQuery('a.btn-xs.' + this)[0]) {
                    var displayName = this.replace(/[_-]/g, ' ');

                    jQuery('#filter_crumbs').prepend('<a class="btn btn-xs ' + this + '" id="' + this + '">' + displayName + '<i class="glyphicon glyphicon-remove"></i></a>');
                }

            });



            jQuery('#regions-tabs > li > a i').removeClass('active');

            jQuery('.tab-content.country-tabs > div').each(function() {
                var commonID = jQuery(this).attr('id');
                if (commonID == 'north_america') {
                    commonID = 'north-america';
                }
                //alert( commonID );
                jQuery(this).children('.checked').each(function() {
                    jQuery('#regions-tabs > li > a.' + commonID + ' i').addClass('active');
                });


            });

            //var regions = jQuery('input:checked').attr('value');
            jQuery.ajax({
                type: "GET",
                data: {
                    region: regions,
                    mediatype: mediatypes,
                    action: 'gallery_filter'
                },
                dataType: "JSON",
                url: ajaxurl,
                beforeSend: function() {},
                success: function(data) {
                    jQuerydata = jQuery(data);
                    jQuerydata.hide();
                    jQuerycontent.html(jQuerydata);
                    jQuerydata.fadeIn(500, function() {
                        loading = false;
                    });

                    var jQuerynewContentDiv = jQuery('<div id="content">');
                    jQuery('#content').replaceWith(jQuerynewContentDiv);
                    jQuery('#content').html(jQuerydata)
                        .imagesLoaded(function() {
                            jQuery('#content').masonry({
                                columnWidth: 270,
                                itemSelector: '.item-masonry',
                                isFitWidth: true,
                                singleMode: false, //expanded addition
                                resizeable: true, //expanded addition
                                // isAnimated: !Modernizr.csstransitions
                            });
                        });
                   


                    function restoreBoxes() {
                        var len = jQuery('.expanded').length - 1;
                        jQuery('.expanded').each(function(i) {
                            var box = jQuery(this).data('size');
                            jQuery(this).animate({
                                    width: (box[0] || 100),
                                    height: (box[1] || 'auto'),
                                    //width: '25%',
                                    //height: 100,
                                }, function() {
                                    if (i >= len) {
                                        jQuery('#content').masonry();
                                    }
                                })
                                .removeClass('expanded');
                        })
                    }

                    jQuery('.item-masonry').click(function() {
                        setTimeout(function() {
                            jQuery('body').animate({
                                scrollTop: jQuery('.item-masonry.expanded').offset().top - 105
                            }, 'slow');
                        }, 1200);
                    });


                },
                error: function(jqXHR, textStatus, errorThrown) {
                    alert(jqXHR + " :: " + textStatus + " :: " + errorThrown);
                }
            });

        }
        jQuery('.mediatype li').click(function() {
            jQuery('.mediatype li a').removeClass('active');
            jQuery(this).children('a').addClass('active');
            var mediatypes = jQuery(this).children('a').attr('id');

            jQuery('#media_type').attr('value', mediatypes);
            load_gallery();
        });
        jQuery('.country-tabs input, .country-tabs select').on('change', function() {
            var content_offset = jQuerycontent.offset();

            setTimeout(function() {
                load_gallery()
            }, 200);
        });
        //load_gallery();  
    });



    // remove a filter and breadcrumb by clicking on the X
    jQuery(document).on('click', '.glyphicon-remove', function() {
        var filterChange = jQuery(this).parent().attr('id');

        if (filterChange == 'reset') {
            jQuery('.breadcrumbs > a:not(#reset)').remove();
            jQuery('label.checkbox.checked').removeClass('checked').children('input').attr('checked', false).trigger('change');
        } else {
            jQuery(this).parent().remove(); // removes the crumb

            //uncheck the filter
            jQuery('input[value=' + filterChange + ']').attr('checked', false).parent().removeClass('checked');
            jQuery('input[value=' + filterChange + ']').attr('checked', false).change();
        }
        blackTabs();

    });




    jQuery('.breadcrumbs .btn-xs').each(function() {
        var id = jQuery(this).attr('id');
        jQuery('.checkbox input[value="' + id + '"]').parent().addClass('checked');
        //alert(' crumb:'+id);
        jQuery('.checkbox input[value="' + id + '"]').attr('checked', true).change();

        //alert('ok');
        setTimeout(function() {
            blackTabs();
        }, 100);

    });

    function blackTabs() {

        jQuery('#regions-tabs > li > a i').removeClass('active');

        jQuery('.tab-content.country-tabs > div').each(function() {
            var commonID = jQuery(this).attr('id');
            //alert( commonID );
            jQuery(this).children('.checked').each(function() {
                jQuery('#regions-tabs > li > a.' + commonID + ' i').addClass('active');
            });
        });

    }

});