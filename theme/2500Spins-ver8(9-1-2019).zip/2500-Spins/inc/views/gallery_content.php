<?php 

$mediaType = get_field( "gallery_type", $post->ID );
if($mediaType == 'photo'){
	$imageThumb = get_the_post_thumbnail_url($post->ID, 'medium_large');
	$fullImage = get_the_post_thumbnail_url($post->ID, 'full');
?>   
<div class="item-masonry type-photo no-soc">
        <div class="open-close"></div><!-- .open-close -->
        <div class="photo">
            <div class="short-border"></div>
            <h1><?php the_title();?></h1>
            <div class="short-border"></div>
            <div class="photo-description">
                <p><?php the_content();?></p>
            </div><!-- .photo-description -->
            <div class="photo-related">
                <h2><a href="">View This Trip &gt;</a></h2>
            </div><!-- .photo-related -->
            <div class="photo-tags"></div><!-- .photo-tags -->
        </div><!-- .photo -->
        <div class="thumb" style="background-image:url(<?php echo $imageThumb;?>);"></div><!-- .thumb -->
        <div class="feature" style="background-image:url(<?php echo $fullImage;?>);"></div><!-- .feature -->
    </div><!-- .item-masonry -->
<?php }elseif($mediaType == 'video'){ ?>
<div class="item-masonry type-video no-soc">
        <div class="open-close"></div><!-- .open-close -->
        <div class="video">
            <div class="play"></div><!-- .play -->
            <h1>Tuscany Explorer 2018</h1>
            <div class="short-border"></div>
            <div class="video-description"> </div><!-- .video-description -->
            <div class="video-tags"></div><!-- .video-tags -->
        </div><!-- .video -->
        <div class="feature" style="background-image:url(http://img.youtube.com/vi/qC-KImQl3CA/maxresdefault.jpg);">
            <iframe class="player" width="560" height="315" src="//www.youtube.com/embed/qC-KImQl3CA?list=UUP3Sd8L0dilIQbL_Fn9z8kg?version=3&enablejsapi=1" frameborder="0" allowfullscreen></iframe></div><!-- .feature -->
        <!-- End -->
    </div><!-- .item-masonry -->   
<?php }elseif($mediaType == 'testi'){ ?>
    <div data-ajax="true" class="item-masonry type-testimonials no-soc">
        <div class="open-close"></div><!-- .open-close -->         
            <div class="testimonial">
                <h3><span>Europe</span><span>France</span></h3>
                <h1>Tour de France Ultimate with Jens Voigt</h1>
                <h2><span>Europe</span><span>France</span></h2>
                <div class="short-border"></div>
                <div class="excerpt">
                    &ldquo;This was truly a trip of a lifetime.&rdquo;
                </div><!-- .excerpt -->
                <div class="full-quote">
                    <p>This was truly a trip of a lifetime. I&#8217;m still talking about it to all my friends.</p>
                    <p class="read-more"><a href="/trips/">See trips like this &gt;</a></p> 
                </div><!-- .full-quote -->
                <div class="short-border"></div>
                <div class="author">Kendall</div><!-- .author -->
            </div><!-- .testimonial -->          
    </div><!-- .item-masonry -->
<?php    
} 
?>