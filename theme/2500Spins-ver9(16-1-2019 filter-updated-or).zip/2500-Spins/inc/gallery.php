<?php 
add_shortcode('gallery_controller', 'gallery_controller_func');
function gallery_controller_func()
{	
	// Load regions
	$regions = get_terms( array(
	    'taxonomy' => 'regions',
	    'hide_empty' => false,
	) );

    ob_start();
    echo '<div class="breadcrumbs" id="filter_crumbs"></div>';
    if($regions){
    	echo '<ul id="regions-tabs" class="regions-tabs">';
    	foreach($regions as $region){
    		if($region->slug == 'asia-facific')
    			$classActive = 'active';
    		else $classActive = '';
    		$region_image = get_wp_term_image($region->term_id);
    		echo '<li><a href="#'.$region->slug.'" class="content-box-sizing '.$region->slug.' '.$classActive.'" style="background-image: url('.$region_image.')"><i class="used"></i>'.$region->name.'</a></li>';
    	}
    	echo '</ul>';
    }
    // Load country off Region
    $asia 			= get_field_object('field_5c331ac14892a');
    $europe 		= get_field_object('field_5c331a3043f3a');
    $latinAmerica   = get_field_object('field_5c331b089eb9d');
    $northAmerica   = get_field_object('field_5c331b590d34e');
    echo '<div id="country-tabs" class="tab-content country-tabs">';
    	if($asia){
    		echo '<div class="tab-pane active" id="asia-facific">';
    		foreach( $asia["choices"] as $key => $choice ) {
    			echo '<label class="checkbox inline"><input type="radio" id="'.$key.'" name="country-tabs" value="'.$key.'"><span class="check"></span> '.$choice.'</label>';
    		}
    		echo '<label class="checkbox inline"><input type="radio" id="all" value="all" name="country-tabs" checked><span class="check"></span> All</label>';
    		echo '</div>';
    	}

    	if($europe){
    		echo '<div class="tab-pane" id="europe">';
    		foreach( $europe["choices"] as $key => $choice ) {
    			echo '<label class="checkbox inline"><input type="radio" id="'.$key.'" name="country-tabs" value="'.$key.'"><span class="check"></span> '.$choice.'</label>';
    		}
    		echo '</div>';
    	}

    	if($latinAmerica){
    		echo '<div class="tab-pane" id="latin-america">';
    		foreach( $latinAmerica["choices"] as $key => $choice ) {
    			echo '<label class="checkbox inline"><input type="radio" id="'.$key.'" name="country-tabs" value="'.$key.'"><span class="check"></span> '.$choice.'</label>';
    		}
    		echo '</div>';
    	}

    	if($northAmerica){
    		echo '<div class="tab-pane" id="north-america">';
    		foreach( $northAmerica["choices"] as $key => $choice ) {
    			echo '<label class="checkbox inline"><input type="radio" id="'.$key.'" name="country-tabs" value="'.$key.'"><span class="check"></span> '.$choice.'</label>';
    		}
    		echo '</div>';
    	}
    echo '</div>';
    // Load Gallery Type
    $mediaType 			= get_field_object('field_5c331cedb4d6e');
    if($mediaType){
    	echo '<div class="mediaType-tabs"><ul class="mediatype">';
    	foreach( $mediaType["choices"] as $key => $choice ) {
    			echo '<li><a id="'.$key.'" class="'.$key.'" >'.$choice.'</a></li>';
    	}
    	echo '<li><a id="all" class="all active" >All</a></li>';
    	echo '<input type="hidden" value="video" id="media_type">';
    	echo '</ul></div>';

    }
    return ob_get_clean();
}


add_shortcode('gallery_show', 'gallery_show_func');
function gallery_show_func(){

	$terms = array( 'asia-facific' ); // Asia first show.

	$args = array(
	    'post_type' => '25000spins_gallery',
        'tax_query' => array(
            array(
                'taxonomy' => 'regions',
                'field'    => 'slug',                 
                'terms'    => $terms
            ),
        ),
	   //      'meta_query' => array(
	   //      	array(
				// 	'key'		=> 'gallery_type',
				// 	'compare'	=> 'IN',
				// 	'value'		=> array( 'video', 'photo', 'testi', 'all' ),
				// ),
	   //      )
	);
	ob_start(); 

	$post = new WP_Query( $args );

	if ( $post->have_posts() ) {
	 	echo '<div id="content" class="gallery-wrapper">';
	    while ( $post->have_posts() ) {
	 
	        $post->the_post();

	        include(THEME_URL_FOLDER.'/inc/views/gallery_content.php');
	 
	    }
	    echo '</div>';
	 
	}
	 
	wp_reset_postdata();

	return ob_get_clean();
}


add_action( 'wp_ajax_gallery_filter', 'gallery_filter_ajax' );
add_action( 'wp_ajax_nopriv_gallery_filter', 'gallery_filter_ajax' );
function thongbao_init() {
 
    $region = (isset($_POST['region']))?esc_attr($_POST['region']) : '';
    $region = explode(",",$region);
	$region = array_filter($region,'strlen'); 
	$region = implode(",",$region);
    $mediatype = (isset($_POST['mediatype']))?esc_attr($_POST['mediatype']) : '';
    $data = array();

    $terms = array( 'asia-facific' ); // Asia first show.

	$args = array(
	    'post_type' => '25000spins_gallery',
        'tax_query' => array(
            array(
                'taxonomy' => 'regions',
                'field'    => 'slug',                 
                'terms'    => $terms
            ),
        ),
	   //      'meta_query' => array(
	   //      	array(
				// 	'key'		=> 'gallery_type',
				// 	'compare'	=> 'IN',
				// 	'value'		=> array( 'video', 'photo', 'testi', 'all' ),
				// ),
	   //      )
	);

    wp_send_json_success($data);
 
    die();
}