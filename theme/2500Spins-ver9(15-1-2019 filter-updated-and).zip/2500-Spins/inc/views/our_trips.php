<?php 
	$args = array(  
       'post_type' => 'event',
       'post_status' => 'publish',
       'posts_per_page' => -1,
       'orderby' => 'date',
       'order' => 'ASC',
   );

   $loop = new WP_Query( $args );
   echo "<div class='our_trips owl-carousel owl-theme'>";
   while ( $loop->have_posts() ) : $loop->the_post();
    $fields = get_fields();
    $regionz = get_field('regions');
    $re = array();
    foreach($regionz as $region){
       $re[] =  $region["label"];
    }
   	?>  
      <div class="et_pb_module et_pb_code et_pb_code_5" style="background-image: url(<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full'); ?>);">
        <div class="et_pb_code_inner">
          <h4><?php the_title(); ?></h4>
            <!-- <p class="date">3-9 March 2018</p>  -->
            <p class="date"><?php echo date("j F", strtotime($fields['time_event']['start_date'])).' - '.date("j F", strtotime($fields['time_event']['end_date'])).' '.date("Y", strtotime($fields['time_event']['end_date'])); ?></p> 
            <p class="location"><?php echo implode(",",$re);?></p> 
            <div class="take_part"><a href="/25000spins/trip-finder/">TAKE PART</a></div>
        </div> <!-- .et_pb_code_inner -->
      </div>
    <?php
   endwhile;
   echo "</div>";;
?>