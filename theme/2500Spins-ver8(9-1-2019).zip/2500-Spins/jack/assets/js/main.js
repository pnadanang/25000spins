'use strict';

jQuery(function($){

    var defaultFilter = {
        'price' : {'min':100, 'max': 9999}
    };
    var filters = defaultFilter;

    var $grid;

    setUpFindRidersPage();
    setUpGalleryPage();
    setUpLeaderBoardPage();

    // onChangeRegions();
    // onChangeCycleTypes();
    // onChangePrices();

    /*Find Riders page*/
    onChangeMonths();
    onChangeCheckBoxes('regions-filter');
    onChangeCheckBoxes('cycle-filter');
    onClearFilters();

    function setUpLeaderBoardPage () {
        $("#leaderBoardTable").tablesorter({
            widgets: ["zebra"],
            // theme : 'gray'
        });
    }

    function onClearFilters () {
        // clear-all
        $('.clear-all').click(function( ) {
            // $grid.isotope('destroy')
            filters = defaultFilter
            $grid.isotope({
                filter: '*'
            });
        })
    }

    function onChangeCycleTypes () {
        // cycle_type
        $('input[name=cycle-filter]').on('change', function () {
            var $this = $(this);
            // - get all checked values
            // - create filter string
            // check if all values are checked.
            var allValues   = $('input[name=cycle-filter]');
            var checkedValues = $('input[name=cycle-filter]:checked');

            var filterWrapper = $this.parents('.filter-wrapper');
            var filterKey = filterWrapper.data('filter-group');
            // console.log(filterKey)
            if (allValues.length === checkedValues.length) {
                filters[filterKey] = '';
            } else {
                var checkedValues = $('input[name=cycle-filter]:checked').map(function() {
                    // var checkedValues = $this.prop('checked', true).map(function() {
                    // console.log(this.value)
                    return '.' + this.value
                }).get().join(', ');
                // - use it inside the code.
                // - Import to filter variable
                filters[filterKey] = checkedValues;
            }
            // console.log()filters
            /*Set up with Iso JS*/
            console.log(getLastFilterSetting())
            $grid.isotope({ filter: getLastFilterSetting() });
            // $grid.isotope({ filter: checkedValues }); // just filter for this Group.
        })
    }

    function onChangeCheckBoxes(type) {
        // type = cycle-filter, regions-filter
        $('input[name='+type+']').on('change', function () {
            var $this = $(this);
            // - get all checked values
            // - create filter string
            // check if all values are checked.
            var allValues   = $('input[name='+type+']');
            var checkedValues = $('input[name='+type+']:checked');

            var filterWrapper = $this.parents('.filter-wrapper');
            var filterKey = filterWrapper.data('filter-group');
            // console.log(filterKey)
            if (allValues.length === checkedValues.length) {
                filters[filterKey] = '';
            } else {
                var checkedValues = $('input[name='+type+']:checked').map(function() {
                    // var checkedValues = $this.prop('checked', true).map(function() {
                    // console.log(this.value)
                    return '.' + this.value
                }).get().join(', ');
                // - use it inside the code.
                // - Import to filter variable
                filters[filterKey] = checkedValues;
            }
            // console.log()filters
            /*Set up with Iso JS*/
            // var filter_temp = getLastFilterSetting();
            // console.log( filter_temp )
            // return;
            $grid.isotope({ filter: getLastFilterSetting() });
            // $grid.isotope({ filter: checkedValues }); // just filter for this Group.
        })
    }

    function concatValues (object) {
        // - convert from objects to string of values
        var keys = Object.keys(object); // price
        var movedIndexKey = 0;
        keys.map(function (keyItem, index) {
            if (keyItem === 'price') movedIndexKey = index;
        })
        return Object.values(object).filter(function (item, index) {
            return index !== movedIndexKey
        }).join('');
    }

    // return Filter string.
    function formatFilters () {
        if ( filters.hasOwnProperty('region') ) {
            var temp = filters;
            /*Get other filters except "region" with values*/ // otherFilterString
            var allKeys = Object.keys(filters);
            // console.log(allKeys)
            // var filterKeys = allKeys.filter(function (item) {
            //     return item !== 'region'
            // }).join('');

            // console.log(filters)
            var otherFilterString = Object.values(filters).filter(function (item, index) {
                var key = allKeys[index];
                return ( key !== 'region' && key !== 'price' )
            }).join('');

            // console.log(otherFilterString) // string
            // ================// ================// ===============
            // (.au, .nz, .asia) * date * cycle_type
            // console.log(otherFilterString)
            // 0: ".jan"
            // return;
            var filterValues = filters.region.split(', ').map(function (item, index) {
                // console.log(item)
                return item.concat(otherFilterString)
            }).join(', ');
            return filterValues;
        }
        return null;
    }

    function getLastFilterSetting() {
        var checkFormatFilter = formatFilters();
        var isoFilterValue;
        if (checkFormatFilter)
            isoFilterValue = checkFormatFilter;
        else isoFilterValue = concatValues(filters)
        console.log(isoFilterValue)
        return isoFilterValue;
    }

    function onChangeMonths() {
        // date-filter
        // - Set up group key for each Filter types
        // - group_key = 'date'
        $('.date-filter .month').on('click', function() {
            var $this = $(this);
            // - hide other current "active" classes
            $this.siblings('.month').removeClass('active');
            // - "active" css
            $this.addClass('active');
            // - set up for riders items. OK
            // - get value "month" of riders items.
            var filterValue = $this.data('filter'); // data-filter
            filterValue = '.' + filterValue;
            // - Update value for "filter" global variable
            var filterWrapper = $this.parents('.filter-wrapper');
            var filterKey = filterWrapper.data('filter-group');
            filters[filterKey] = filterValue;
            // - set filter by code of Iso library
            $grid.isotope({ filter: getLastFilterSetting() });
        });
    }

    function onChangeRegions () {
        $('input[name=regions-filter]').on('change', function () {
            var $this = $(this);
            // - get all checked values
            // - create filter string
            var checkedValues = $('input[name=regions-filter]:checked').map(function() {
            // var checkedValues = $this.prop('checked', true).map(function() {
                return '.' + this.value
            }).get().join(', ');

            // - use it inside the code.
            // - Import to filter variable
            var filterWrapper = $this.parents('.filter-wrapper');
            var filterKey = filterWrapper.data('filter-group');
            filters[filterKey] = checkedValues;
            /*Set up with Iso JS*/
            $grid.isotope({ filter: getLastFilterSetting() });
            // $grid.isotope({ filter: checkedValues }); // just filter for this Group.
        })
    }

    function setUpFindRidersPage () {
        $('input[name=regions-filter]').prop('checked', true);

        $grid = $('#find-riders-list').isotope({
            itemSelector: '.person-item',
            layoutMode: 'fitRows',
            filter : function () {
                var $this = $(this);
                var price = $this.attr('data-price');
                // console.log(filters.price.min)
                // console.log(filters.price.max)

                var isInPriceRange = (filters.price.min <= price && filters.price.max >= price);
                // console.log(isInPriceRange)
                return isInPriceRange;
                // ----------------------
                // var isInHeightRange = (rangeFilters['height'].min <= height && rangeFilters['height'].max >= height);
            }
        });
        /*get all regions*/
        // var all_regions = $('input[name=regions-filter]').map(function () {
        //     return '.' + this.value }).get().join(', ');
        // filters.region = all_regions;
        // console.log(filters)
        // $grid.isotope({ filter: all_regions })

        /*Set up Price Slider from Bootstrap*/
        // var $priceSlider = $('#filter-price').slider({
        //     tooltip_split: true,
        //     min: 100,
        //     max: 1000,
        //     range: true,
        //     // value: [150, 180]
        // });
        // console.log($priceSlider)

        var minValue = $('#filter-price').prop('min'); // filter-price
        var maxValue = $('#filter-price').prop('max');
        $("#filter-price").ionRangeSlider({
            skin: "round",
            type: "double",
            grid: false,
            min: minValue,
            max: maxValue,
            from: minValue,
            to: maxValue,
            onStart: function (data) {
                updateFilterSelection(data)
            },
            onChange: function (data) {
                updateFilterSelection(data)
            },
            onFinish: function (data) {
                var from = data.from;
                var to = data.to;
                filters.price = {
                    min: from || 0,
                    max: to || 9999
                };
                console.log($grid)
                $grid.isotope();
            },
            // prefix: "$",
        });
    }

    function updateFilterSelection (data) {
        var from = data.from;
        var to = data.to;
        $('.filter-selection').text(from + '-' + to);
    }

    function setUpGalleryPage () {
        // WP Frank
        $('a[href="https://www.wpfrank.com/"]').parent().hide();
    }

})
