<?php

if ( !defined('THEME_URL_FOLDER') ) {
    define('THEME_URL_FOLDER', get_stylesheet_directory() );
}


require_once THEME_URL_FOLDER . '/jack/config/index.php';
require_once THEME_URL_FOLDER . '/jack/inc/helpers.php';
require_once THEME_URL_FOLDER . '/jack/inc/actions.php';
require_once THEME_URL_FOLDER . '/jack/inc/shortcode.php';

add_action('wp_enqueue_scripts', 'jack_import_style_js_files');
function jack_import_style_js_files () {
    wp_enqueue_style('jack-css', trailingslashit(get_stylesheet_directory_uri()) . 'jack/assets/css/index.css', array());

    wp_enqueue_script('jack-js', trailingslashit(get_stylesheet_directory_uri()) . 'jack/assets/js/main.js', array('jquery'), null, true);
}
