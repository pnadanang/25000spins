<div id="blog-section">
    <div class="blog-wrapper">
        <?php
        if ($blogs->have_posts()) :
            while ($blogs->have_posts()) : $blogs->the_post();
                ?>
                <div class="blog-wrapper-box">
                    <div class="featured-image">
                        <img src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full'); ?>" alt="">
                    </div>
                    <div class="blog-details">
                        <h2 class="blog-title"><?php the_title(); ?></h2>
                        <p class="blog-date"><?php echo get_the_date('M / d / Y'); ?></p>
                        <p class="blog-excerpt"><?php echo wp_trim_words(get_the_excerpt(), 30); ?><a
                                href="<?php the_permalink(); ?>" class="blog-readmore">READ MORE <i
                                    class="fa fa-angle-right"></i></a></p>
                    </div>
                </div>
            <?php
            endwhile;
        endif;
        wp_reset_postdata();
        ?>
    </div>
</div>
