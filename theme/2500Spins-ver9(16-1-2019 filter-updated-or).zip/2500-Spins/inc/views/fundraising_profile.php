<li>
	<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
		<img src="<?php echo get_the_post_thumbnail_url();?>" alt="<?php the_title(); ?>">
	</a>
	<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
	<?php 
	if( '' !== get_post()->post_content ) { 
	?><?php the_excerpt();?><?php 
	}
	?>
</li>