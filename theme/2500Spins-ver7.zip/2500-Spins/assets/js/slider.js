jQuery(document).ready(function($) {
// ========================================
    $('.our_trips').owlCarousel({
        loop:true,
        margin:20,
        responsiveClass:true,
        // autoplay:true,
        dots: false,
        nav:true,
        autoplayTimeout: 8500,
        smartSpeed: 450,
        navText: ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
        responsive:{
            0:{
                items:1
            },
            600:{
                items:2
            },
            1000:{
                items:4
            }
        }
    });

    $('#blog-slider .owl-carousel').owlCarousel({
        loop:true,
        margin:0,
        responsiveClass:true,
        // autoplay:true,
        dots: true,
        nav:false,
        autoplayTimeout: 8500,
        smartSpeed: 450,
        navText: ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
        responsive:{
            0:{
                items:1
            },
            600:{
                items:1
            },
            1000:{
                items:1
            }
        }
    });

    $('.completed_charity').owlCarousel({
        loop:true,
        margin:20,
        responsiveClass:true,
        // autoplay:true,
        dots: false,
        nav:true,
        autoplayTimeout: 8500,
        smartSpeed: 450,
        navText: ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
        responsive:{
            0:{
                items:1
            },
            600:{
                items:2
            },
            1000:{
                items:4
            }
        }
    });

// =====================================================
  var bigimage = $(".big");
  var thumbs = $(".thumbs");
  var syncedSecondary = true;

  bigimage
    .owlCarousel({
    items: 1,
    slideSpeed: 2000,
    // center: true,
    nav: true,
    autoplay: false,
    dots: false,
    loop: true,
    responsiveRefreshRate: 200,
    navText: [
      '<i class="fa fa-angle-left" aria-hidden="true"></i>',
      '<i class="fa fa-angle-right" aria-hidden="true"></i>'
    ]
  })
    // .on("changed.owl.carousel", syncPosition);

  var $owl = $('.thumbs');
  $owl.children().each( function( index ) {
    $(this).attr( 'data-position', index ); // NB: .attr() instead of .data()
  });

  $owl.owlCarousel({
    center: true,
    loop: true,
    items: 3,
    // nav: true,
  }).on("changed.owl.carousel", syncPosition2);
  $(document).on('click', '.owl-item>div', function() {
    $owl.trigger('to.owl.carousel', $(this).data( 'position' ) );
  });

  function syncPosition2(el) {
    if (syncedSecondary) {
      var number = el.item.index;
      var number_1 = number - 3;
      // console.log(number_1);
      bigimage.data("owl.carousel").to(number_1, 100, true);
    }
  }
  $('#slider_home .et_pb_column.big .owl-nav button.owl-prev').click(function(){
      // console.log('prev');
      $owl.trigger('prev.owl.carousel');
  });
  $('#slider_home .et_pb_column.big .owl-nav button.owl-next').click(function(){
      // console.log('next');
      $owl.trigger('next.owl.carousel');
  });
// ===========================================
// console.log('OK');
});
