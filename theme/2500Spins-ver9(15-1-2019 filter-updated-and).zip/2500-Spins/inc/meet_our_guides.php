<?php 
function wpcodex_add_excerpt_support_for_our_guides() {
   add_post_type_support( 'our_guides', 'excerpt' );
}
add_action( 'init', 'wpcodex_add_excerpt_support_for_our_guides' );

add_shortcode('meet_our_guides', 'meet_our_guides_func');
function meet_our_guides_func()
{	
	$args = array(
	  'posts_per_page' => 6,
	  'post_type'   => 'our_guides'
	);
    $our_guides = new WP_Query( $args );
    //var_dump($our_guides); die();
    ob_start();
    if ( $our_guides->have_posts() ) {
    	echo '<ul class="meet-our-guides-list">';
        while ($our_guides->have_posts()) {

            $our_guides->the_post();

            include(THEME_URL_FOLDER.'/inc/views/meet_our_guides.php');

        }
        echo '</ul>';
    }

    return ob_get_clean();
}

// fundraising_profiles
// 
add_shortcode('fundraising_profiles', 'fundraising_profiles_func');
function fundraising_profiles_func()
{   
    $args = array(
      'posts_per_page' => 12,
      'post_type'   => 'fundraising_profiles'
    );
    $our_guides = new WP_Query( $args );
    //var_dump($our_guides); die();
    ob_start();
    if ( $our_guides->have_posts() ) {
        echo '<ul class="fundraising-profiles-list">';
        while ($our_guides->have_posts()) {

            $our_guides->the_post();

            include(THEME_URL_FOLDER.'/inc/views/fundraising_profile.php');

        }
        echo '</ul>';
        devvn_wp_corenavi($our_guides);
    }

    return ob_get_clean();
}
add_shortcode('rider_profiles', 'rider_profiles_func');
function rider_profiles_func()
{   
    $args = array(
      'posts_per_page' => 12,
      'post_type'   => 'riders'
    );
    $our_guides = new WP_Query( $args );
    //var_dump($our_guides); die();
    ob_start();
    if ( $our_guides->have_posts() ) {
        echo '<ul class="rider-profiles-list">';
        while ($our_guides->have_posts()) {

            $our_guides->the_post();

            include(THEME_URL_FOLDER.'/inc/views/rider_profile.php');

        }
        echo '</ul>';
        devvn_wp_corenavi($our_guides);
    }

    return ob_get_clean();
}
function devvn_wp_corenavi($custom_query = null, $paged = null) {
    global $wp_query;
    if($custom_query) $main_query = $custom_query;
    else $main_query = $wp_query;
    $paged = ($paged) ? $paged : get_query_var('paged');
    $big = 999999999;
    $total = isset($main_query->max_num_pages)?$main_query->max_num_pages:'';
    if($total > 1) echo '<div class="pagenavi">';
    echo paginate_links( array(
        'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
        'format' => '?paged=%#%',
        'current' => max( 1, $paged ),
        'total' => $total,
        'mid_size' => '5',
        'prev_text'    => __('Prev','devvn'),
        'next_text'    => __('Next','devvn'),
    ) );
    if($total > 1) echo '</div>';
}