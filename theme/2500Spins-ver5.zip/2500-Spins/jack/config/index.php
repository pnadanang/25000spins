<?php

/**
 * Mode
 * 1. Individual
 * 2. team
 */

define('THEME_PATH', get_stylesheet_directory_uri());
