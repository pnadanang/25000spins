<?php

add_shortcode('trip_finder', 'trip_finder_func');
add_shortcode('blog_list', 'blog_list_func');
add_shortcode('breadcrumb_page', 'breadcrumb_page_func');

// https://webjuicy.com/25000spins/trip-finder/
function trip_finder_func($args)
{	$query = get_trip_finder();
	$terms = get_terms( 'event_category',array('hide_empty' => false,'order'=>"DESC") );
    ob_start();
    include_once THEME_URL_FOLDER.'/inc/views/trip_finder.php';
    wp_reset_query();
    return ob_get_clean();
}
//Get post in post type event
if(!function_exists('get_trip_finder'));
function get_trip_finder() {
	if(isset($_GET['term'])){
		$term =$_GET['term'];
	}else{
		$term ='trips';
	}
	$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
    $arg = array(
        'post_type' => 'event',
        'posts_per_page' => 5,
        'order' => 'ASC',
        'orderby' => 'date',
        'paged' => $paged,
        'tax_query' => array(
    		array(
    			'taxonomy' => 'event_category',
    			'field' => 'slug',
    			'terms' => $term
    		),
	   ),
    );
    $event = new WP_Query($arg);
    return $event;
}
// https://webjuicy.com/25000spins/stories/
function blog_list_func($args)
{
    /*Blog*/
    $blogs = get_blogs();

    ob_start();
    include_once THEME_URL_FOLDER.'/inc/views/blog_list.php';
    return ob_get_clean();
}

function get_blogs() {
    $args = array(
        'post_type' => 'post',
        'posts_per_page' => -1,
        'order' => 'ASC',
        'orderby' => 'date'
    );
    $parent = new WP_Query($args);
    return $parent;
}
//------------------
function breadcrumb_page_func(){
    ob_start();
    ?>
        <div class="breadcrumb-page">   
        <?php
            global $post;
            if (!is_home()) {
                echo "";
                    if(is_single()):
                    // echo 'Main';
                    else:
                    echo "HOME";
                    endif;
                echo " / ";
                    if ( is_category() || is_single() ) {
                        the_category(', ');
                        if ( is_single() ) {
                            echo " / ";
                            ?>
                                <strong><?php echo the_title(); ?></strong>
                            <?php
                        }
                    }
                    elseif ( is_page() && $post->post_parent ) {
                        echo get_the_title($post->post_parent);
                        echo " / ";
                        ?>
                            <strong><?php echo the_title(); ?></strong>
                        <?php
                    }
                    elseif (is_page()) {
                        echo "";
                        ?>
                            <strong><?php echo the_title(); ?></strong>
                        <?php
                        echo "";
                    }
                }

        ?>
        </div>
    <?php
    return ob_get_clean();
}
//------------------
// add_action("wp_ajax_process_data_ajax","process_data_ajax");
// add_action("wp_ajax_nopriv_process_data_ajax","process_data_ajax");
// function process_data_ajax(){
//     if(isset($_POST['requestdata'])){
//         $requestdata = $_POST['requestdata'];
//         print_r(ajax_filter_shortcode($requestdata));
//     }
//     die();
// }

// function ajax_filter_shortcode($requestdata){
//     $arg = array(
//         'post_type' => 'event',
//         'posts_per_page' => -1,
//         'order' => 'ASC',
//         'orderby' => 'date',
//         'tax_query' => array(
//             array(
//                 'taxonomy' => 'event_category',
//                 'field' => 'slug',
//                 'terms' => $requestdata['term']
//             ),
//        ),
//     );
//     if(!empty($requestdata['region']) || !empty($requestdata['cylce']) ){
//         $meta_query = array('relation' => 'AND');
//     }
//     if(!empty($requestdata['region'])){
//         foreach ($requestdata['region'] as $value) {
//             $meta_query[] = array(
//                 'key'       => 'regions',
//                 'value'     => $value,
//                 'compare'   => 'LIKE',
//             );
//         }
//     }
//     if (!empty($requestdata['cylce'])) {
//         foreach ($requestdata['cylce'] as $value) {
//             $meta_query[] = array(
//                 'key'       => 'cycle_type',
//                 'value'     => $value,
//                 'compare'   => 'LIKE',
//             );
//         }
//     }
//     if (!empty($requestdata['price'])) {
//             $min = $requestdata['price'][0];
//             $max = $requestdata['price'][1];
//         $meta_query[] = array(
//                 'key'       => 'price',
//                 'value'     => array($min,$max),
//                 'compare'   => 'BETWEEN',
//                 'type' => 'numeric'
//             );
//     }
// $arg['meta_query'] = $meta_query;
// $query = new WP_Query($arg);
// $count = $query->post_count;
//     ob_start();
//     // print_r($requestdata);
//     if($count !=0){
//        include_once THEME_URL_FOLDER.'/inc/views/ajax_html.php'; 
//     }else{
//         echo "<h4 style='text-align:center'>No result!<h4>"; 
//     }
//     wp_reset_query();
//     return ob_get_clean();

// }