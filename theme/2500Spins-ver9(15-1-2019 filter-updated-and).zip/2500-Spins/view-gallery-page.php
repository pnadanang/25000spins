<?php 
	// get_header();
	// echo "<div class='container'>";
	// $id_gallery = $_GET['gallery'];
	// echo do_shortcode('[FAG id='.$id_gallery.']');
	// echo "</div>";
	// get_footer();

get_header();
?>
	<div class="container">
		<?php
			$id_gallery = $_GET['gallery'];
			echo do_shortcode('[FAG id='.$id_gallery.']'); 
		?>
	</div> <!-- .container -->
<?php
get_footer();

?>
