<div id="search-page" class="leaderboard-page">
    <div class="row">
		<!--<img src="<?= THEME_PATH . '/jack/assets/images/leaderboard_title.png' ?>">-->
    </div>
    <div id="content-container">
        <div class="row">
            <div class="top-search">
                <div class="search_box">
                    <form role="search" method="get" class="leaderboard_search">
						<?php
						printf( '<input type="search" class="et-search-field search" placeholder="SEARCH" value="%2$s" name="s" title="%3$s" />',
							esc_attr__( 'Search &hellip;', 'Divi' ),
							get_search_query(),
							esc_attr__( 'Search for:', 'Divi' )
						);
						?>
                        <i class="fa fa-search search_icon" aria-hidden="true"></i>
                    </form>
                </div>
                <div class="type">
                    <ul>
                        <?php
                        $page_url = get_page_link();
                        foreach ($type_array as $type_item) {
                            ?>
                            <li><a href="<?= $page_url ?>?type=<?= $type_item ?>" class="<?= ($type == $type_item) ? 'active' : '' ?>"><?= lcfirst($type_item) ?></a></li>
                            <?php
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Search box -->
        <!-- Category menu -->
        <!-- Table list -->

        <!--<div class="row">-->
        <!--    <div class="search"></div>-->
        <!--    <div>-->
        <!---->
        <!--    </div>-->
        <!--    <div>-->
        <!---->
        <!--    </div>-->
        <!--</div>-->


        <div class="row">
            <table id="leaderBoardTable" class="tablesorter">
                <thead>
                    <tr>
                        <th>Rank</th>
                        <th>Athlete</th>
                        <th>Fundraised</th>
                        <th data-sorter="false"></th>
                    </tr>
                </thead>
                <tbody class="list">
				<?php
				if (isset($riders) && ! empty( $riders ) ) {
//					jack_pr($riders);
					foreach ($riders as $index => $rider) {
						$rank       = $index+1;
//	                $image_url  = "https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50";

						$image_url = 'https://cdn.gofundraise.com.au' . $rider->ImagePath;
                        $leaderboard_page = "https://gofundraise.com.au" . $rider->PageUrl;
                        $leaderboard_donate = "https://gofundraise.com.au/payments/donate/page/" . $rider->Id;
						?>
<!--                        <div style="display: none">--><?php //jack_pr($rider) ?><!--</div>-->
                        <tr>
                            <td class="rank"><?= $rank ?></td>
                            <td class="avatar-name">
                                <a href="<?= $leaderboard_page ?>" class="athlete-avatar" >
                                    <img src="<?= $image_url ?>">
                                </a>
                                <a class="name" href="<?= $leaderboard_page ?>">
                                    <span class="name-text"><?= $rider->name ?></span>
                                </a>
                            </td>
                            <td>$ <?= $rider->TotalRaised ?></td>
                            <td><a href="<?= $leaderboard_donate ?>" class="donation-button">Donate</a></td>
                        </tr>
						<?php
					}
				}
				?>
                </tbody>
            </table>
        </div>
    </div>
</div>
