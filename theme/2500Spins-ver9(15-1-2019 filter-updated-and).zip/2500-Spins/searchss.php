<?php get_header(); ?>
<div id="search-page">
	<div class="container">
		<div class="top-search">
			<div class="search_box">
					<form role="search" method="get" class="" action="<?php echo esc_url( home_url( '/' ) ); ?>">
					<?php
						printf( '<input type="search" class="et-search-field" placeholder="SEARCH" value="%2$s" name="s" title="%3$s" />',
							esc_attr__( 'Search &hellip;', 'Divi' ),
							get_search_query(),
							esc_attr__( 'Search for:', 'Divi' )
						);
					?>
					<i class="fa fa-search search_icon" aria-hidden="true"></i>
					</form>
			</div>
			<div class="type">
				<ul>
					<li><a href="#" class="active">TRIPS</a></li>
					<li><a href="#" >TRIPS</a></li>
					<li><a href="#" >TRIPS</a></li>
					<li><a href="#" >TRIPS</a></li>
				</ul>
			</div>
		</div>
		<div class="bottom-search">
			<div class="filter-widget">
				<div class="filter-widget-box">
					<h4>REGIONS</h4>
					<div class="filter-wrapper regions-filter">
						<div class="input-filter">
							<input type="checkbox" name=""><label>Europe</label>
						</div>
						<div class="input-filter">
							<input type="checkbox" name=""><label>Europe</label>
						</div>
						<div class="input-filter">
							<input type="checkbox" name=""><label>Europe</label>
						</div>
						<div class="input-filter">
							<input type="checkbox" name=""><label>Europe</label>
						</div>
						<div class="input-filter">
							<input type="checkbox" name=""><label>Europe</label>
						</div>
					</div>
				</div>
				<!-- -------------------------------------- -->
				<div class="filter-widget-box">
					<h4>DATE</h4>
					<div class="filter-wrapper date-filter">
						<p class="year">2018</p>
						<span class="month">JAN</span>
						<span class="month">JAN</span>
						<span class="month">JAN</span>
						<span class="month active">JAN</span>
						<span class="month">JAN</span>
						<span class="month">JAN</span>
						<span class="month">JAN</span>
						<span class="month active">JAN</span>
						<span class="month">JAN</span>
						<span class="month">JAN</span>
					</div>
				</div>
				<!-- --------------------------------------- -->
				<div class="filter-widget-box">
					<h4>CYLCE TYPE</h4>
					<div class="filter-wrapper regions-filter">
						<div class="input-filter">
							<input type="checkbox" name=""><label>ROAD</label>
						</div>
						<div class="input-filter">
							<input type="checkbox" name=""><label>MOUNTAIN</label>
						</div>
					</div>
				</div>
				<!-- --------------------------------------- -->
				<div class="filter-widget-box">
					<h4>PRICE</h4>
					<div class="filter-wrapper price-filter">
						<div class="input-filter">
							    <input type="range" class="range-slider-price" min="100" max="1000"/>
						</div>
						<div class="value-get">
							<div class="min_price">
								<span>Min Price</span>
								<span class="label_price">$ 100</span>
							</div>
							<div class="line-through">
								<span>-----</span>
							</div>
							<div class="max_price">
								<span>Max Price</span>
								<span class="label_price">$ 1000</span>
							</div>
						</div>
					</div>
				</div>
				<div class="clear-all">
					<span>Clear all filters</span>
				</div>
			</div>
			<div class="result-data">
				
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>