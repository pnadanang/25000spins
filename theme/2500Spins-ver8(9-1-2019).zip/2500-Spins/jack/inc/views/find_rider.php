<?php
if ( isset( $_GET['term'] ) ) {
	$termiput = $_GET['term'];
} else {
	$termiput = 'trips';
}
?>
<div id="search-page" class="page-find-rider">
    <div class="">
        <div class="top-search">
            <div class="search_box">
                <form role="search" method="get" class="" action="<?php echo esc_url( home_url( '/' ) ); ?>">
					<?php
					printf( '<input type="search" class="et-search-field" placeholder="SEARCH" value="%2$s" name="s" title="%3$s" />',
						esc_attr__( 'Search &hellip;', 'Divi' ),
						get_search_query(),
						esc_attr__( 'Search for:', 'Divi' )
					);
					?>
                    <i class="fa fa-search search_icon" aria-hidden="true"></i>
                </form>
            </div>
            <div class="type">
                <ul>
	                <?php
	                $page_url = get_page_link();
	                foreach ( $terms as $term ):
		                if ( $term->slug == 'trips' && ! isset( $_GET['term'] ) ) {
			                $active = "active";
		                } else if ( $term->slug == $_GET['term'] ) {
			                $active = "active";
		                } else {
			                $active = "";
		                }
		                ?>
                        <li><a href="<?php echo $page_url; ?>?term=<?php echo $term->slug; ?>"
                               class="<?php echo $active ?>"><?php echo $term->name; ?></a></li>
	                <?php
	                endforeach;
	                ?>
                </ul>
            </div>
        </div>

        <div class="bottom-search">
            <div class="filter-widget">
                <div class="filter-widget-box">
                    <h4>REGIONS</h4>
                    <div class="filter-wrapper regions-filter" data-filter-group="region">
                        <div class="input-filter">
                            <input type="checkbox" name="regions-filter" value="europe"><label>Europe</label>
                        </div>
                        <div class="input-filter">
                            <input type="checkbox" name="regions-filter" value="north-america"><label>North
                                America</label>
                        </div>
                        <div class="input-filter">
                            <input type="checkbox" name="regions-filter" value="au"><label>Australia</label>
                        </div>
                        <div class="input-filter">
                            <input type="checkbox" name="regions-filter" value="nz"><label>New Zealand</label>
                        </div>
                        <div class="input-filter">
                            <input type="checkbox" name="regions-filter" value="asia"><label>Asia</label>
                        </div>
                    </div>
                </div>

                <!-- -------------------------------------- -->
<!--                <div class="filter-widget-box">-->
<!--                    <h4>DATE</h4>-->
<!--                    <div class="filter-wrapper date-filter" data-filter-group="date">-->
<!--                        <p class="year">--><?php //if ( isset( $current_year ) ): echo $current_year; endif; ?><!--</p>-->
<!--						--><?php
//						if ( isset( $months ) && ! empty( $months ) && is_array( $months ) ) {
//							// - get current month
//							$current_month = get_current_month();
//							foreach ( $months as $index => $month ) {
//								$month_value = $index + 1;
//								$month_class = '';
//								// - set color for current month and "active"
//								if ( $month_value == $current_month ) {
////	                                $month_class = 'active';
//								} // - set color for previous months
//								else if ( $month_value < $current_month ) {
//									$month_class = 'previous';
//								} // - set color for next months.
//								else if ( $month_value > $current_month ) {
//									$month_class = 'next';
//								}
//								?>
<!--                                <span data-filter="--><?//= strtolower( $month ) ?><!--"-->
<!--                                      class="ripple month --><?//= $month_class ?><!--">--><?//= strtoupper( $month ) ?><!--</span>-->
<!--								--><?php
//							}
//						}
//						?>
<!--                    </div>-->
<!--                </div>-->
                <!-- --------------------------------------- -->
<!--                <div class="filter-widget-box">-->
<!--                    <h4>CYLCE TYPE</h4>-->
<!--                    <div class="filter-wrapper regions-filter" data-filter-group="cycle">-->
<!--                        <div class="input-filter">-->
<!--                            <input type="checkbox" name="cycle-filter" value="road"><label>ROAD</label>-->
<!--                        </div>-->
<!--                        <div class="input-filter">-->
<!--                            <input type="checkbox" name="cycle-filter" value="mountain"><label>MOUNTAIN</label>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
                <!-- --------------------------------------- -->
                <div class="filter-widget-box">
                    <h4>PRICE</h4>
                    <div class="filter-wrapper price-filter" data-filter-group="price">
                        <div class="input-filter">
                            <!-- Custom Filter height -->
                            <span class="filter-label">Price Range: <span class="filter-selection"></span> </span>
                            <!-- TODO: update new version -->
                            <input id="filter-price" type="text" min="100" max="9999">
                            <!-- END: Custom Filter height -->
<!--                            <input type="range" class="range-slider-price" min="100" max="1000"/>-->
                        </div>
                        <div class="value-get">
                            <div class="min_price">
                                <span>Min Price</span>
                                <span class="label_price">$ 100</span>
                            </div>
                            <div class="line-through">
                                <span>-----</span>
                            </div>
                            <div class="max_price">
                                <span>Max Price</span>
                                <span class="label_price">$ 9999</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clear-all">
                    <span>Clear all filters</span>
                </div>
            </div>
            <div class="result-data grid" id="find-riders-list">
				<?php
				if ( isset( $riders ) && ! empty( $riders ) ) {

//                    jack_pr($riders);
					foreach ( $riders as $rider ) {
						// region, date, cycle_type, price
						/*format data to string*/
						$data_attr = [
							'data-type'   => '', // road, mountain.
							'data-region' => $rider->region,
							'data-donate' => $rider->TotalRaised,
							'data-month'  => get_random_month_from_timestamp(),
                            'data-price'  => $rider->TotalRaised,
						];
						array_walk( $data_attr, function ( &$value, $key ) {
							$value = "$key='$value'";
						} );
						$data_string = implode( ' ', $data_attr );
						//

						/*format to Class string*/
						$class_attr   = [
							$rider->region,
							// - TODO: Update month of date of Donation
							( get_random_month_from_timestamp() ),
//							$rider->TotalRaised,
							$cycle_types[ rand( 0, 1 ) ]
						];
						$class_attr   = array_map( function ( $item ) {
							return strtolower( $item );
						}, $class_attr );
						$class_string = implode( ' ', $class_attr );

						/*images*/
						$image_path = 'https://cdn.gofundraise.com.au' . $rider->ImagePath;
						?>
                        <div class="grid-item person-item <?= $class_string ?>"
                             style="background-image : url(<?php echo $image_path ?>)" <?php echo $data_string ?>>
                            <div class="overlay"></div>
<!--                            <img class="person-icon" src="--><?//= THEME_PATH . '/jack/assets/images/orange-people.png' ?><!--">-->
                            <div class="bottom">
                                <h1><?= $rider->name ?></h1>
                                <a class="donate-button" href="<?= "https://gofundraise.com.au" . $rider->PageUrl ?>">DONATE</a>
                            </div>
                        </div>
						<?php
					}
				}
				?>
            </div>
        </div>
    </div>
</div>
