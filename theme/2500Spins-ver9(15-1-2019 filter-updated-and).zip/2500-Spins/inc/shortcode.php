<?php

add_shortcode('list_album_flick', 'list_album_flick_func');
add_shortcode('trip_finder', 'trip_finder_func');
add_shortcode('blog_list', 'blog_list_func');
add_shortcode('breadcrumb_page', 'breadcrumb_page_func');
add_shortcode('our_trips', 'our_trips_func');

// https://webjuicy.com/25000spins/trip-finder/
function trip_finder_func($args)
{	$query = get_trip_finder();
	$terms = get_terms( 'event_category',array('hide_empty' => false,'order'=>"DESC") );
    ob_start();
    include_once THEME_URL_FOLDER.'/inc/views/trip_finder.php';
    wp_reset_query();
    return ob_get_clean();
}
//Get post in post type event
if(!function_exists('get_trip_finder'));
function get_trip_finder() {
	if(isset($_GET['term'])){
		$term =$_GET['term'];
	}else{
		$term ='trips';
	}
	$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
    $arg = array(
        'post_type' => 'event',
        'posts_per_page' => 5,
        'order' => 'ASC',
        'orderby' => 'date',
        'paged' => $paged,
        'tax_query' => array(
    		array(
    			'taxonomy' => 'event_category',
    			'field' => 'slug',
    			'terms' => $term
    		),
	   ),
    );
    $event = new WP_Query($arg);
    return $event;
}
// https://webjuicy.com/25000spins/stories/
function blog_list_func($args)
{
    /*Blog*/
    $blogs = get_blogs();

    ob_start();
    include_once THEME_URL_FOLDER.'/inc/views/blog_list.php';
    return ob_get_clean();
}

function get_blogs() {
    $args = array(
        'post_type' => 'post',
        'posts_per_page' => -1,
        'order' => 'ASC',
        'orderby' => 'date'
    );
    $parent = new WP_Query($args);
    return $parent;
}
//------------------
function breadcrumb_page_func(){
    ob_start();
    ?>
        <div class="breadcrumb-page">   
        <?php
            global $post;
            if (!is_home()) {
                echo "";
                    if(is_single()):
                    // echo 'Main';
                    else:
                    echo "HOME";
                    endif;
                echo " / ";
                    if ( is_category() || is_single() ) {
                        the_category(', ');
                        if ( is_single() ) {
                            echo " / ";
                            ?>
                                <strong><?php echo the_title(); ?></strong>
                            <?php
                        }
                    }
                    elseif ( is_page() && $post->post_parent ) {
                        echo get_the_title($post->post_parent);
                        echo " / ";
                        ?>
                            <strong><?php echo the_title(); ?></strong>
                        <?php
                    }
                    elseif (is_page()) {
                        echo "";
                        ?>
                            <strong><?php echo the_title(); ?></strong>
                        <?php
                        echo "";
                    }
                }

        ?>
        </div>
    <?php
    return ob_get_clean();
}
// ========================
function list_album_flick_func(){
    ob_start();
     $args = array(  
       'post_type' => 'fa_gallery',
       'post_status' => 'publish',
       'posts_per_page' => -1,
       'orderby' => 'date',
       'order' => 'ASC',
   );

   $loop = new WP_Query( $args );
  echo '<div class="flickr-album"><ul class="list-album">';
   while ( $loop->have_posts() ) : $loop->the_post();
   	$ID = get_the_ID();
   	$FAG_Albums = unserialize(get_post_meta( $ID, 'fag_settings', true));
   	if(is_array($FAG_Albums)){
		foreach($FAG_Albums as $FAG_Album) {
      //var_dump($FAG_Album);
      $API_KEY = $FAG_Album['fag_api_key'];
      $ALBUM_ID = $FAG_Album['fag_album_id'];
      $response = file_get_contents("https://api.flickr.com/services/rest/?format=json&jsoncallback=&method=flickr.photosets.getPhotos&api_key=".$API_KEY."&photoset_id=".$ALBUM_ID."");

   $response = str_replace("jsonFlickrApi(","",$response);
   $response = str_replace(")","",$response);
   $response = json_decode($response, true);
   //var_dump($response); die();
   if($response["stat"] == 'ok' && isset($response["photoset"]["photo"][0])){
      $farm = $response["photoset"]["photo"][0]["farm"];
      $server = $response["photoset"]["photo"][0]["server"];
      $id = $response["photoset"]["photo"][0]["id"];
      $secret = $response["photoset"]["photo"][0]["secret"];
      $img = "https://farm{$farm}.static.flickr.com/{$server}/{$id}_{$secret}_b.jpg";
   }else{
      $img = get_home_url('/').'/wp-content/uploads/2019/01/No_Image_Available.jpg';
   }
      echo '<li><a href="'.get_home_url('/').'/gallery/?gallery='.get_the_ID().'" title="'.get_the_title().'"><img src="'.$img.'" alt="'.get_the_title().'"><h3>'.get_the_title().'</h3></a></li>';
		}
	}
    ?>
    <!-- <a href="?gallery=<?php echo get_the_ID(); ?>"><?php the_title(); ?></a> -->
    <?php
   endwhile;
   echo '</ul></div>';
   return ob_get_clean();
}
// ========================
function our_trips_func(){
   ob_start();
   include_once THEME_URL_FOLDER.'/inc/views/our_trips.php';
   return ob_get_clean();
}
//------------------
// add_action("wp_ajax_process_data_ajax","process_data_ajax");
// add_action("wp_ajax_nopriv_process_data_ajax","process_data_ajax");
// function process_data_ajax(){
//     if(isset($_POST['requestdata'])){
//         $requestdata = $_POST['requestdata'];
//         print_r(ajax_filter_shortcode($requestdata));
//     }
//     die();
// }

// function ajax_filter_shortcode($requestdata){
//     $arg = array(
//         'post_type' => 'event',
//         'posts_per_page' => -1,
//         'order' => 'ASC',
//         'orderby' => 'date',
//         'tax_query' => array(
//             array(
//                 'taxonomy' => 'event_category',
//                 'field' => 'slug',
//                 'terms' => $requestdata['term']
//             ),
//        ),
//     );
//     if(!empty($requestdata['region']) || !empty($requestdata['cylce']) ){
//         $meta_query = array('relation' => 'AND');
//     }
//     if(!empty($requestdata['region'])){
//         foreach ($requestdata['region'] as $value) {
//             $meta_query[] = array(
//                 'key'       => 'regions',
//                 'value'     => $value,
//                 'compare'   => 'LIKE',
//             );
//         }
//     }
//     if (!empty($requestdata['cylce'])) {
//         foreach ($requestdata['cylce'] as $value) {
//             $meta_query[] = array(
//                 'key'       => 'cycle_type',
//                 'value'     => $value,
//                 'compare'   => 'LIKE',
//             );
//         }
//     }
//     if (!empty($requestdata['price'])) {
//             $min = $requestdata['price'][0];
//             $max = $requestdata['price'][1];
//         $meta_query[] = array(
//                 'key'       => 'price',
//                 'value'     => array($min,$max),
//                 'compare'   => 'BETWEEN',
//                 'type' => 'numeric'
//             );
//     }
// $arg['meta_query'] = $meta_query;
// $query = new WP_Query($arg);
// $count = $query->post_count;
//     ob_start();
//     // print_r($requestdata);
//     if($count !=0){
//        include_once THEME_URL_FOLDER.'/inc/views/ajax_html.php'; 
//     }else{
//         echo "<h4 style='text-align:center'>No result!<h4>"; 
//     }
//     wp_reset_query();
//     return ob_get_clean();

// }