jQuery(function ($) {
    // $(".result-left").click(function(){
    //     // $(this).
    //     console.log('click');
    //     window.open('http://25000spins.gofundraise.com.au/');
    // })
    $(".action-button a").mouseover(function(){
        $(this).parents('.result-left').removeAttr('onClick');
    });
    $(".action-button a").mouseout(function(){
        $(this).parents('.result-left').attr("onClick", "window.open('http://25000spins.gofundraise.com.au/')");
    });

    $(".result-data-box").mouseover(function(){
        $(this).children('.result-left').addClass('hover');
    });
    $(".result-data-box").mouseout(function(){
        $(this).children('.result-left').removeClass('hover');
    });


    // console.log(211);

    $(window).on('scroll', function () {
        if ($(window).scrollTop() > 500) {
            $("#backtotop").css('display','flex');
        } else {
            $("#backtotop").hide();
        }
    });
     $("#backtotop").on('click', function(e) {
        e.preventDefault();
        $('html, body').animate({scrollTop:0}, '300');
      });
    // =============================
    setInterval(function () {
        // =============================
        var maxHeight_slider = 0;
        var video_box = jQuery('.video-box-homepage').parent('.owl-item');
        $(video_box).each(function () {
            if ($(this).height() > maxHeight_slider) {
                maxHeight_slider = $(this).height();
            }
        });
        $("#slider_home .big .owl-item").height(maxHeight_slider);
        // ====================================
        // $("#slider_home .big .owl-item").css('max-height','400px');
        // $("#slider_home .et_pb_video_box video").css('height','600px!important');
        // ====================================
    }, 100);
// ========================================
    setTimeout(function () {
        $('.full_width_3_col.center span.number').each(function () {
            $(this).prop('Counter', 0).animate({
                Counter: $(this).html()
            }, {
                duration: 6000,
                easing: 'swing',
                step: function (now) {
                    $(this).text(Math.ceil(now).toLocaleString('en'));
                }
            });
        });
    }, 2000);
// =======FILTER OR=================================
    var $container;
    var priceFilter = { 'min':100, 'max': 1000 };
    var filters = [];
    var $grid;

    $container = $('.result-data');

    $grid = $container.isotope({
        itemSelector: '.result-data-box',
        filter : function () {
            var $this = $(this);

            var price = $this.data('price');
            var price_attr = $this.attr('data-price');
            var isInPriceRange = (priceFilter.min <= price && priceFilter.max >= price);
            return isInPriceRange;
        }
    });
    $('.filter-widget').on( 'change', function( jQEvent ) {
        
        var $checkbox = $( jQEvent.target );
        //console.log($checkbox)
        //console.log(filters);
        //console.log(filters);
        var comboFilter = selectAllCheckbox( );
        //console.log(comboFilter);
        $container.isotope({
                itemSelector: '.result-data-box',
                filter : function ( ) {
                    // console.log(comboFilter);
                    var $this = $(this);

                    var price = $this.data('price');
                    var price_attr = $this.attr('data-price');
                    var hasFilter = false;
                    var hasFilterPrice = (priceFilter.min <= price && priceFilter.max >= price);

                    // console.log(comboFilter.length);

                    if(hasFilterPrice){
                        if(comboFilter.length == 0){
                            return true;
                        }else{
                            for(let i = 0; i < comboFilter.length; i++) {
                                if($this.hasClass(comboFilter[i].replace(".",""))){
                                   hasFilter = true; 
                                   break;
                                } else {
                                    hasFilter = false; 
                                }
                            }
                            return hasFilter;
                        }
                    } else return false;
                }
            });
    });
    function getComboFilter( filters ) {
      var i = 0;
      var comboFilters = [];
      var message = [];

      for ( var prop in filters ) {
        message.push( filters[ prop ].join(' ') );
        var filterGroup = filters[ prop ];
        if ( !filterGroup.length ) {
          continue;
        }
        if ( i === 0 ) {
          comboFilters = filterGroup.slice(0);
        } else {
          var filterSelectors = [];
          var groupCombo = comboFilters.slice(0); // [ A, B ]
          for (var k=0, len3 = filterGroup.length; k < len3; k++) {
            for (var j=0, len2 = groupCombo.length; j < len2; j++) {
              filterSelectors.push( groupCombo[j] + filterGroup[k] ); // [ 1, 2 ]
            }
          }
          comboFilters = filterSelectors;
        }
        i++;
      }
      comboFilter = comboFilters;
      return comboFilter;
    }
    function selectAllCheckbox(){
        var filters = [];
        $('.filter-widget label input[type=checkbox]:checked').each(function (index, value) {
            var $value = $(this).val();
            filters.push($value);
        });
        return filters;
    }
    function manageCheckbox( $checkbox ) {
      var checkbox = $checkbox[0];
      var group = $checkbox.parents('.option-set').attr('data-group');
      var filterGroup = filters[ group ];
      if ( !filterGroup ) {
        filterGroup = filters[ group ] = [];
      }

      var isAll = $checkbox.hasClass('all');
      if ( isAll ) {
        delete filters[ group ];
        if ( !checkbox.checked ) {
          checkbox.checked = 'checked';
        }
      }
      var index = $.inArray( checkbox.value, filterGroup );
      if ( checkbox.checked ) {
        var selector = isAll ? 'input' : 'input.all';
        $checkbox.siblings( selector ).removeAttr('checked');
        if ( !isAll && index === -1 ) {
          filters[ group ].push( checkbox.value );
        }
      } else if ( !isAll ) {
        filters[ group ].splice( index, 1 );
        if ( !$checkbox.siblings('[checked]').length ) {
          $checkbox.siblings('input.all').attr('checked', 'checked');
        }
      }
    }
    // ----------------FILTER AND--------------------------------------------
    // var $container;
    // var filters = {};
    // var priceFilter = { 'min':100, 'max': 1000 };
    // $(function(){
    //   $container = $('.result-data');
    //   $container.isotope();
    //   $('.filter-widget').on( 'change', function( jQEvent ) {
    //     var $this = $(this);
    //     var $checkbox = $( jQEvent.target );
    //     manageCheckbox( $checkbox );
    //     var comboFilter = getComboFilter( filters );
    //     $container.isotope({ filter: comboFilter });

    //     var price = $this.data('price');
    //     var price_attr = $this.attr('data-price');
    //     var isInPriceRange = (priceFilter.min <= price && priceFilter.max >= price);
    //     console.log(isInPriceRange);
    //     return isInPriceRange;
    //   });
    // });
    //  function selectAllCheckbox(){
    //     var filters = [];
    //     $('.filter-widget label input[type=checkbox]:checked').each(function (index, value) {
    //         var $value = $(this).val();
    //         filters.push($value);
    //     });
    //     return filters;
    // }
    // function getComboFilter( filters ) {
    //   var i = 0;
    //   var comboFilters = [];
    //   var message = [];

    //   for ( var prop in filters ) {
    //     message.push( filters[ prop ].join(' ') );
    //     var filterGroup = filters[ prop ];
    //     if ( !filterGroup.length ) {
    //       continue;
    //     }
    //     if ( i === 0 ) {
    //       comboFilters = filterGroup.slice(0);
    //     } else {
    //       var filterSelectors = [];
    //       var groupCombo = comboFilters.slice(0); 
    //       for (var k=0, len3 = filterGroup.length; k < len3; k++) {
    //         for (var j=0, len2 = groupCombo.length; j < len2; j++) {
    //           filterSelectors.push( groupCombo[j] + filterGroup[k] ); 
    //         }

    //       }
    //       comboFilters = filterSelectors;
    //     }
    //     i++;
    //   }
    //   var comboFilter = comboFilters.join(', ');
    //   return comboFilter;
    // }
    // function manageCheckbox( $checkbox ) {
    //   var checkbox = $checkbox[0];
    //   var group = $checkbox.parents('.option-set').attr('data-group');
    //   var filterGroup = filters[ group ];
    //   if ( !filterGroup ) {
    //     filterGroup = filters[ group ] = [];
    //   }
    //   var isAll = $checkbox.hasClass('all');
    //   if ( isAll ) {
    //     delete filters[ group ];
    //     if ( !checkbox.checked ) {
    //       checkbox.checked = 'checked';
    //     }
    //   }
    //   var index = $.inArray( checkbox.value, filterGroup );
    //   if ( checkbox.checked ) {
    //     var selector = isAll ? 'input' : 'input.all';
    //     $checkbox.siblings( selector ).removeAttr('checked');
    //     if ( !isAll && index === -1 ) {
    //       filters[ group ].push( checkbox.value );
    //     }
    //   } else if ( !isAll ) {
    //     filters[ group ].splice( index, 1 );
    //     if ( !$checkbox.siblings('[checked]').length ) {
    //       $checkbox.siblings('input.all').attr('checked', 'checked');
    //     }
    //   }
    // }
    // -----------------------END-------------------------------------
    var minValue = $('.range-slider-price[type="range"]').prop('min');
    var maxValue = $('.range-slider-price[type="range"]').prop('max');
    $(".range-slider-price").ionRangeSlider({
        skin: "round",
        type: "double",
        grid: false,
        min: minValue,
        max: maxValue,
        from: minValue,
        to: maxValue,
        onFinish: function (data) {
            var from = data.from;
            var to = data.to;
            // console.log(from);
            // console.log(to);

            priceFilter.min = from || 0;
            priceFilter.max = to || 0;

            var comboFilter = selectAllCheckbox( );

            $container.isotope({
                itemSelector: '.result-data-box',
                filter : function ( ) {

                    console.log(comboFilter);

                    var $this = $(this);
                    var price = $this.data('price');
                    var price_attr = $this.attr('data-price');

                    var hasFilter = false;
                    var hasFilterPrice = (priceFilter.min <= price && priceFilter.max >= price);
                    if(hasFilterPrice){
                        if(comboFilter.length == 0){
                            return true;
                        }else{
                            for(let i = 0; i < comboFilter.length; i++) {
                                if($this.hasClass(comboFilter[i].replace(".",""))){
                                   hasFilter = true; 
                                   break;
                                } else {
                                    hasFilter = false; 
                                }
                            }
                            return hasFilter;
                        }
                    } else return false;
                }
            });
            console.log('update grid isotope')
        },
        // prefix: "$",
    });

    $(".range-slider-price").on("change", function () {
        var $inp = $(this);
        var from = $inp.data("from");   // input data-from attribute
        var to = $inp.data("to");       // input data-to attribute
        $('.min_price span.label_price').text('$ ' + from);
        $('.max_price span.label_price').text('$ ' + to);
       
    });
    // ============================================================
    $('.filter-widget-box h4').click(function () {
        $(this).next('.filter-wrapper').slideToggle(500);
        $(this).toggleClass('close');
    });
    // ==============================
    $(".filter-widget-box input[type='checkbox']").click(function () {
        if ($(this).is(':checked')) {
            $(this).parent('label').addClass('checked');
        } else {
            $(this).parent('label').removeClass('checked');
        }
    });
    // ===================================
    
    $('#menu_responsive ul#menu-primary-menu > li.menu-item-has-children > a').click(function (e) {
        $(this).next('ul.sub-menu').slideToggle();
        $(this).parent('li').toggleClass('open-child');
        e.preventDefault();
    });
    $('#menu_responsive ul#menu-secondary-menu > li.menu-item-has-children > a').click(function (e) {
        $(this).next('ul.sub-menu').slideToggle();
        $(this).parent('li').toggleClass('open-child');
        e.preventDefault();
    });
    $('ul li.search-items-icon a').click(function (e) {
        $('.form-box').slideToggle(300);
        $('.search_responsive_box').slideToggle(300);
        e.preventDefault();
    });
    // $('body').click(function (e) {
    //     $('.search_responsive_box').hide(300);
    //     console.log('hide');
    // });
    $('.form-box .close-form').click(function (e) {
        $('.form-box').hide(200);
        e.preventDefault();
    });
    $('#search_responsive_bar i.fa-search').click(function (e) {
        $('.search_responsive_box').slideToggle(300);
        e.preventDefault();
    });
// ================REMOVE $ SPECIAL CHARACTER========================
	// function numberWithCommas(x) {
	//     return x.toString().replace(/\B(?=(?:\d{3})+(?!\d))/g, ",");
	// }
 //    var string = $('.find-adventure span.raise-so-far-donate-count').html();
 //    var string_change = '';
 //    if (string)
 //         string_change = string.replace("$", "").replace(",", "");
 //    	string_change = Math.ceil(string_change);
 //    v_pound = numberWithCommas(string_change);
 //    v_pound = parseInt(v_pound) + 1720345;
 //    $('.find-adventure span.raise-so-far-donate-count').html(v_pound);
// ================ADD $ AND FORMAT NUMBER========================
    function ReplaceNumberWithCommas(yourNumber) {
        var n= yourNumber.toString().split(".");
        n[0] = n[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return n.join(".");
    }
    var string = $('.find-adventure span.raise-so-far-donate-count').html();
    var string_change = '';
    if (string)
        string_change = string.replace("$", "").replace(",", "");
        string_change = Math.ceil(string_change);
    // v_pound = numberWithCommas(string_change);
    v_pound = parseInt(string_change) + 1720345;
    v_pound = ReplaceNumberWithCommas(v_pound);
    // console.log(v_pound);
    $('.find-adventure span.raise-so-far-donate-count').html('$ '+v_pound);
// ================REMOVE , and . SPECIAL CHARACTER AND ANIMATION NUMBER========================
    var string_2 = $('.full_width_3_col.center span.raise-so-far-donate-count').html();
    var string_change_2 = string_2 ? string_2.replace(',', '').replace('$', '') : "";
    var string_change_2 = Math.ceil(string_change_2);

    string_change_2 = parseInt(string_change_2) + 1720345;
    // console.log(string_change_2);
    // console.log('string_change_2');
    
    $('.full_width_3_col.center span.raise-so-far-donate-count').html(string_change_2);
    $('.full_width_3_col.center span.raise-so-far-donate-count').each(function () {
        $(this).prop('Counter', 0).animate({
            Counter: $(this).html()
        }, {
            duration: 8000,
            easing: 'swing',
            step: function (now) {
                $(this).text(Math.ceil(now).toLocaleString('en'));
            }
        });
    });
// ========================================
    $('#menu_responsive_bar i').click(function () {
        $('#menu_responsive').slideToggle(500);
        // $('#menu_responsive').toggle(500);
        // console.log(1);
    });

    // $('body.page-id-810 #menu_responsive_bar i').click(function () {
    //     $('#menu_responsive').show(500);
    // });
    window.onscroll = function () {
        myFunction()
    };
    var header = document.getElementById("scroll-nav"),
        sticky = header.offsetTop,
        top_menu = $('#top_menu'),
        logo_container = top_menu.children('.logo_container'),
        main_menu_wrapper = $('#main_menu_wrapper'),
        primary_menu = main_menu_wrapper.find('.primary_menu');

    function myFunction() {
        var logo_width = logo_container.width(),
            menu_height = main_menu_wrapper.height();
        if (window.pageYOffset > sticky) {
            header.classList.add("fixedheader");
            // logo_container.css({
            //     'height': menu_height,
            //     'width': logo_width
            // });
            // primary_menu.css('padding-left', logo_width);
        } else {
            header.classList.remove("fixedheader");
            // logo_container.css({'height': ''});
            // primary_menu.css('padding-left', '');
        }
    }
    // ===========================================
    $('.social_share a').click(function(event){
    	event.preventDefault();
    	link = $(this).attr('href');
    	console.log(link);
    	if (link)  
		window.open(
		  	link,
		  	'pop',
		  	"height=590,width=450,toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=auto,resizable=yes,copyhistory=no"
		  	); 
	});
	// ===========================================
        jQuery( ".result-data-box" ).on( "click", "a#register-to-ride", function( e ) {
        e.preventDefault();
        $id = jQuery(this).data("id");
        if(jQuery("#"+$id).is(':visible')){
            jQuery("#"+$id).css({"display":"none"});
        }else{
            jQuery("#"+$id).css({"display":"block"});
        }
    }); 
});

