<?php

function get_events ($name, $region = null) {
    $query = array(
        'query'     => $name,
        'region'    => $region,
        'pagesize'  => 10000
    );
    $url = "https://api.gofundraise.com.au/v1/events/search?" . http_build_query($query);
    $response = wp_remote_get($url);
    if (!is_wp_error($response)) {
        $body   = wp_remote_retrieve_body($response);
        $events = json_decode($body)->Events;
        if (!empty($events)) {
            if (is_array($events)) {
                // array of items.
                return array_map(function ($item) {
                    return (object) [
                        'id' => $item->EventCampaignId,
                        'region' => $item->EventRegion
                    ];
                }, $events);
            }
        }
        // return 0;
    }
    return 0;
}

function get_riders_test() {
    $url = 'https://api.gofundraise.com.au/v1/leaderboards/fundraising?EventCampaignId=5014';
    $response = wp_remote_get($url);
    $body = wp_remote_retrieve_body($response);
}

function get_featured_test ($event_id, $mode, $region) {

    $url = "https://api.gofundraise.com.au/v1/leaderboards/fundraising?EventCampaignId=$event_id";
    $url .= "&Mode=".ucfirst($mode);

    // TODO:
    // - get all charities of this event.

    // - so after that all will be good.

//    $url = 'https://api.gofundraise.com.au/v1/leaderboards/fundraising?';
//    $url .= 'EventCampaignId=' . $event_id;
//    if ($bene_id) $url .= '&BeneficiaryAccountId=' . $bene_id;
//    if (strtolower($mode)=='individual'||strtolower($mode)=='team') $url .= "&Mode=".ucfirst($mode);
//    if ($size) $url .= "&Size=$size";
//    else {
//        $page_type = 'S';
//        if (strtolower($mode)=='team') {
//            $page_type = 'T';
//        }
//        $url .= "&Size=" .get_count($event_id,$bene_id,$page_type,'AU');
//    }
    // --------------------------------------
    $response = wp_remote_get($url);
    if (is_wp_error($response)) return array();
    $body = json_decode($response['body']);
    if (!isset($body->Leaderboard)) return array();

    return array_map(function($item) use ($region) {
        $item->region = $region;
        $item->name = $item->FirstName . ' ' . $item->LastName;
        return $item;
    }, $body->Leaderboard);
}

function check_expired_cache_time ($cachefile) {
    if (file_exists($cachefile) && (time() - CACHE_TIME < filemtime($cachefile)) ) {
        return false;
    }
    return true;
}

function create_cache_files ($cachefile, $data) {
    $cached = fopen($cachefile, 'w');
    fwrite($cached, $data);
    fclose($cached);
}

// Format event id
function format_events ($event_data) {
    $raw_event_ids = explode(',',$event_data);
    return array_filter($raw_event_ids, function ($item){
        return is_numeric($item);
    });
}

function check_attr($name, $array) {
    if (is_array($array) && array_key_exists($name, $array) && $array[$name]) return true;
    return false;
}

