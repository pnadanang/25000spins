<?php

function get_fundraisers_by_event ($event_id) {

}

// Format event id
function get_events ($event_data) {
    $raw_event_ids = explode(',',$event_data);
    return array_filter($raw_event_ids, function ($item){
        return is_numeric($item);
    });
}

function check_attr($name, $array) {
    if (array_key_exists($name, $array) && $array[$name]) return true;
    return false;
}
