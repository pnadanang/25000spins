'use strict';

jQuery(function($) {
    setUpLeaderBoardPage();

    onChangeClickHeading();

    function setUpLeaderBoardPage () {
        /*set up search list*/
        var options = {
            valueNames: [ 'name-text', 'rank' ]
        };

        var hackerList = new List('content-container', options);
        console.log(hackerList)

        // --------

        $("#leaderBoardTable").tablesorter({
            widgets: ["zebra"],
            // theme : 'gray'
        });

        $('.leaderboard_search').submit(function () {
            return false;
        });
    }

    function onChangeClickHeading () {
        $('#leaderBoardTable thead tr th').click(function () {
            var $this = $(this);
            console.log('clicked')
            // - get index of the value
            var index = $this.index();
            console.log(index)
            // - set up for body
            $('#leaderBoardTable tbody tr').each(function () {
                var tr_container = $(this).find("td").eq(index);
                $(this).find("td").siblings().removeClass('active')
                $(this).find("td").eq(index).addClass('active')
            })
        });
    }
});
