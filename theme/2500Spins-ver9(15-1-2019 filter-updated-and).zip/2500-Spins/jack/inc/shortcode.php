<?php

add_shortcode('find_rider', 'find_rider_func');
add_shortcode('leaderboard-page', 'leaderboard_func');

function leaderboard_func ($atts) {
//	$array = array(12,4,5);
//	jack_pr($array);
	if (!check_attr('event-name', $atts)) return '';
	$event_name = $atts['event-name'];

	$type_array = ['individual', 'team'];
	if (isset($_GET['type'])) {
		$type = $_GET['type'];
	} else $type = 'individual';
//	jack_pr($type);
//	$type       = $atts['type'];
	// ----------------------

	// if ( isset( $_GET['term'] ) ) {
	//	$termiput = $_GET['term'];
	//} else {
	//	$termiput = 'trips';
	//}

	$events  = get_events($event_name);
    //var_dump($events); die();

	$riders = get_all_riders($events, $type);
//	jack_pr($riders);
	$terms = get_terms( 'event_category',array('hide_empty' => false,'order'=>"DESC") );

	ob_start();
//    $benefic = get_beneficiary_by_search(7739);
//     echo '<div style="display: none !important;" id="jack" >' .print_r($benefic). '</div>';
	include_once THEME_URL_FOLDER.'/jack/inc/views/leaderboard.php';
	return ob_get_clean();
}

/**
 * Find Riders
 * - event-name
 * - type : 'rider', 'team'
 * ==================================
 * * TODO
 * - get all regions at this time.
 * - Support multiple events
 */
function find_rider_func ($atts) {
    ob_start();

//    if (!check_attr('eventid', $atts)) return '';
    if (!check_attr('event-name', $atts)) return '';
    $event_name = $atts['event-name'];
    $type       = $atts['type'];
    // --------------------------------
	$terms = get_terms( 'event_category',array('hide_empty' => false,'order'=>"DESC") );

    $events  = get_events($event_name);
    $riders = get_all_riders($events, $type);

    /*Filter section*/
	$current_year   = get_current_year();
	$months         = get_short_month_names();
	$cycle_types    = get_cycle_types();

    include_once THEME_URL_FOLDER.'/jack/inc/views/find_rider.php';
    return ob_get_clean();
}

// ----------------------------------------------------------------------
function get_all_riders ($events, $type) {
	$riders = array();
	foreach ($events as $event) {
        /**
         * Get charity of Rider.
         * - BeneficiaryAccountId
         * - BeneficiaryName
         * - BeneficiaryUrl
         * - BeneficiaryTheme['BannerImage']
         */
        $benefic = get_beneficiary_by_search( $event->id );
//        jack_pr($benefic);

		$riders_by_event = get_riders_by_event_id($event->id, $type, $event->region, $benefic);
//        var_dump($benefic); die();
		$riders = array_merge($riders, $riders_by_event);
	}
	return $riders;
}

function get_data ($event_ids, $type) {
    // 1 type
    // array of regions
    // $type , $region

    $people = array();

    /*get all regions*/
    $regions = get_supported_regions();
    foreach ($regions as $region) {

        /*get riders with 1 region.*/
        $riders = get_riders($event_ids, $type , $region);
        // TODO:
        // searhc
        $people = array_merge($people, $riders);
    }

    return $people;
}

function get_mode ($type) {
    switch ($type) {
        case 'rider':
	    case 'individual':
	    	return 'S';
	    case 'team':
		    return 'T';
        default : return $type;
    }
}

function get_supported_regions () {
    return array(
        'US',
        'AU',
        'NZ'
    );
}

function check_region ($region) {
    //  US, AU, NZ
    $region = strtoupper($region);
    $region_from_api = get_supported_regions();
    if ( in_array($region, $region_from_api) ) return true;
    return false;
}
// create_cache_files
// check_expired_cache_time

// leaderboard_widget_function
/**
 * Function save cache files.
 */
function get_riders ($event_ids, $type , $region) {
    $bene_id    = null;
    $size       = null;
    // TODO: Check mode.
    $mode       = get_mode($type);
    // mode
    // TODO: Check cache files right here.
    //
    $cache_file = JACK_DIR . "/cache/$type-$region.txt";
    $cache_file = JACK_DIR . "/cache/$type-$region.txt";
    if (check_expired_cache_time($cache_file)) {

        $items = array();

        if (!empty($event_ids)) {

            foreach ($event_ids as $event_id) {
                // TODO:
                // - Update Live code for featured.
//            $funders = get_featured ($event_id, $bene_id, $size, $mode , $region );
                // - get events by region

                // - TODO:
                // 1. create function return $event_id by "region", "name"
                $funders = get_featured_test($event_id, $mode, $region);

                if (!empty($funders)) {
                    // array_push($items, $funders);
                    $items = array_merge($items, $funders);
                }
            }
        }

        // Display cache files.
        if (!empty($items)) {
            create_cache_files($cache_file, serialize($items));
            $data = $items;
        } else {
            $content    = file_get_contents($cache_file);
            $data       = unserialize($content);
        }
    } else {
        $content        = file_get_contents($cache_file);
        $data           = unserialize($content);
    }

    return $data; // array of items
}

/**
 * Get charity of Rider.
 * - BeneficiaryAccountId
 * - BeneficiaryName
 * - BeneficiaryUrl
 * - BeneficiaryTheme->BannerImage
 */
function get_riders_by_event_id ($event_id, $type, $region = null, $charity = array()) {
    $bene_id    = null;
    $size       = null;
    // TODO: Check mode.
    $mode       = get_mode($type);

    /*Each events have each regions*/
    $cache_file = JACK_DIR . "/cache/$event_id-$type-$region.txt";
//    jack_pr($cache_file);
    $data = array();
    if (check_expired_cache_time($cache_file)) {

        $funders = get_featured_test($event_id, $mode, $region, $charity);
        // ------------------------------
        if (!empty($funders)) {
            $data = array_merge($data, $funders);
        }
//        jack_pr($items);

        if (!empty($data)) {
            create_cache_files($cache_file, serialize($data));
        }
//        else {
//            $content    = file_get_contents($cache_file);
//            $data       = unserialize($content);
//        }
    } else {
        $content        = file_get_contents($cache_file);
        $data           = unserialize($content);
    }

    return $data;
}
