<?php

function jack_pr($array) {
    echo '<pre>';
    print_r($array);
    echo '</pre>';
    die();
}
