<?php
if (!defined('ABSPATH')) exit;

define('THEME_URL_FOLDER', get_stylesheet_directory());
require_once THEME_URL_FOLDER . '/jack/index.php';
require_once THEME_URL_FOLDER . '/inc/shortcode.php';

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

if (!function_exists('chld_thm_cfg_parent_css')):
    function chld_thm_cfg_parent_css()
    {
        wp_enqueue_style('chld_thm_cfg_parent', 'https://cdnjs.cloudflare.com/ajax/libs/ion-rangeslider/2.3.0/css/ion.rangeSlider.min.css', array());
        wp_enqueue_style('rangeSlider-css', trailingslashit(get_template_directory_uri()) . 'style.css', array());
        // wp_enqueue_style('embed-css', 'https://assets.juicer.io/embed.css', array());

        /*Custom Theme style*/
        wp_enqueue_style('main-css', trailingslashit(get_stylesheet_directory_uri()) . 'assets/css/main.css', array());
        wp_enqueue_style('font-awesome-css', 'https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
        wp_enqueue_style('OwlCarousel', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css');

        wp_enqueue_script('OwlCarousel-js', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js', array());
        // wp_enqueue_script('embed-js', 'https://assets.juicer.io/embed.js', array('jquery'));
        wp_enqueue_script('rangeSlider-js', 'https://cdnjs.cloudflare.com/ajax/libs/ion-rangeslider/2.3.0/js/ion.rangeSlider.min.js', array('jquery'));
        

        wp_enqueue_script('main-js', trailingslashit(get_stylesheet_directory_uri()) . 'assets/js/main.js', array('jquery'), null, true);
        wp_localize_script('main-js', 'mainjs_ajax_object',array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
        wp_enqueue_script('slider-js', trailingslashit(get_stylesheet_directory_uri()) . 'assets/js/slider.js', array('jquery'), null, true);

    }
endif;
add_action('wp_enqueue_scripts', 'chld_thm_cfg_parent_css', 10);

// add_action('wp_enqueue_scripts', 'my_theme_load_scripts');
// function my_theme_load_scripts(){
//    if(is_page($post->ID == 436)){ //Check if we are viewing a page
//         wp_enqueue_script('rangeSlider-js', 'https://cdnjs.cloudflare.com/ajax/libs/ion-rangeslider/2.3.0/js/ion.rangeSlider.min.js', array('jquery'));
//    }
// }
 


add_filter('widget_text', 'do_shortcode');
// =========================================
function wpb_widgets_init()
{
    register_sidebar(array(
        'name' => __('Social Footer', 'wpb'),
        'id' => 'social-footer',
        'description' => __('Appears on the static front page template', 'wpb'),
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '',
        'after_title' => '',
    ));
}

add_action('widgets_init', 'wpb_widgets_init');

add_filter('http_request_host_is_external', '__return_true');

add_action( 'init', 'create_event_posttype_init' );
function create_event_posttype_init() {
    $labels = array(
        'name'               => _x( 'Events', 'post type general name', 'event-ctp' ),
        'singular_name'      => _x( 'Event', 'post type singular name', 'event-ctp' ),
        'menu_name'          => _x( 'Events', 'admin menu', 'event-ctp' ),
        'name_admin_bar'     => _x( 'Event', 'add new on admin bar', 'event-ctp' ),
        'add_new'            => _x( 'Add Event', 'event', 'event-ctp' ),
        'add_new_item'       => __( 'Add New Event', 'event-ctp' ),
        'new_item'           => __( 'New Event', 'event-ctp' ),
        'edit_item'          => __( 'Edit Event', 'event-ctp' ),
        'view_item'          => __( 'View Event', 'event-ctp' ),
        'all_items'          => __( 'All Events', 'event-ctp' ),
        'search_items'       => __( 'Search Events', 'event-ctp' ),
        'parent_item_colon'  => __( 'Parent Events:', 'event-ctp' ),
        'not_found'          => __( 'No events found.', 'event-ctp' ),
        'not_found_in_trash' => __( 'No events found in Trash.', 'event-ctp' )
    );

    $args = array(
        'labels'             => $labels,
        'description'        => __( 'Description.', 'event-ctp' ),
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'event' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' )
    );
    register_post_type( 'event', $args );

    register_taxonomy( 'event_category', // register custom taxonomy - category
        'event',
        array(
            'hierarchical' => true,
            'labels' => array(
                'name' => 'Events category',
                'singular_name' => 'Event category',
            )
        )
    );
}
