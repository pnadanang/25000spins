<?php
function get_auth(){
    /*Each events have each regions*/
    $cache_file = JACK_DIR . "/cache/auth-token.txt";
//    jack_pr($cache_file);
    $data = array();
    if (check_expired_cache_time($cache_file)) {

        $client_id  = 'd9cf2f34-cbe7-4004-bd07-09df8150baf4';
        $client_secret  = 'YLH5BvEReYiZJuwxbjqrDbY4m2fNJbvm6sVDVamSgJOsrC6LGHfCy3JjoQhhEuWRqy2xvs5iYDU4kGokmyKiNacQogJbb8XpWT3NUu7Kay8jPBQpTpskLpiyNk42FR4Q';
        $url = "https://api.gofundraise.com.au/v1/oauth/token";
        $args = array(
            'method' => 'POST',
            'timeout' => 45,
            'redirection' => 5,
            'httpversion' => '1.0',
            'blocking' => true,
            'headers' => array(),
            'body' => array( 'client_id' => $client_id, 'client_secret' => $client_secret, 'grant_type' => 'client_credentials' ),
            'cookies' => array()
        );
        $response = wp_remote_post( $url, $args );
        if ( is_wp_error( $response ) ) {
           $data = array();
        } else {
           $data = wp_remote_retrieve_body($response);
        }
        //var_dump($data); die();
        if (!empty($data)) {
            create_cache_files($cache_file, serialize($data));
        }
    } else {
        $content        = file_get_contents($cache_file);
        $data           = unserialize($content);
    }
    return json_decode($data, true);

}
function get_events ($name, $region = null) {
    $query = array(
        'query'     => $name,
        'region'    => $region,
        'pagesize'  => 10000
    );
    $url = "https://api.gofundraise.com.au/v1/events/search?" . http_build_query($query);
    $response = wp_remote_get($url);
    if (!is_wp_error($response)) {
        $body   = wp_remote_retrieve_body($response);
        $events = json_decode($body)->Events;
        if (!empty($events)) {
            if (is_array($events)) {
                // array of items.
                return array_map(function ($item) {
                    return (object) [
                        'id' => $item->EventCampaignId,
                        'region' => $item->EventRegion
                    ];
                }, $events);
            }
        }
        // return 0;
    }
    return 0;
}

function get_beneficiary( $eventCampaignId ){
    global $wp_version;
    $token = get_auth();
//    var_dump($eventCampaignId); die();
    $query = array(
        'EventCampaignId'     => $eventCampaignId

    );
    $url = "https://api.gofundraise.com.au/v1/events/{$eventCampaignId}/beneficiaries?" . http_build_query($query);
    $args = array(
        'timeout'     => 5,
        'redirection' => 5,
        'httpversion' => '1.0',
        'user-agent'  => 'WordPress/' . $wp_version . '; ' . home_url(),
        'blocking'    => true,
        'headers'     => array(
            'Accept' => 'application/json',
            'Authorization' => $token['token_type'].' '.$token['access_token']
        ),
        'cookies'     => array(),
        'body'        => array(),
        'compress'    => false,
        'decompress'  => true,
        'sslverify'   => true,
        'stream'      => false,
        'filename'    => null
    );
    $response = wp_remote_get( $url, $args );
    if ( is_wp_error( $response ) ) {
           $data = array();
        } else {
           $data = wp_remote_retrieve_body($response);
    }
//    var_dump( $data); die();
    return $data;
}

function get_beneficiary_by_search ($event_id, $type = 'AU') {
    $query = array(
        'eventcampaignid' => $event_id,
        'region' => $type
    );
    $url = "https://api.gofundraise.com.au/v1/beneficiaries/search?" . http_build_query($query);
    $response = wp_remote_get($url);
    if ( is_wp_error( $response ) ) {
        $data = array();
    } else {
        $data = wp_remote_retrieve_body($response);
        $data = json_decode($data, true);

        $beneficiaries = $data['Beneficiaries'];
        if (!empty($beneficiaries)) {
            return $beneficiaries[0];
        }
    }
    return $data;
}

function get_riders_test() {
    $url = 'https://api.gofundraise.com.au/v1/leaderboards/fundraising?EventCampaignId=5014';
    $response = wp_remote_get($url);
    $body = wp_remote_retrieve_body($response);
}

function get_featured_test ($event_id, $mode, $region, $charity) {

    // GET charity (beneficiary) the rider is supporting
    //$url_benefic = "https://api.gofundraise.com.au/v1/events/{$event_id}/beneficiaries";
    //$benefic = get_beneficiary( $eventCampaignId );


    $url = "https://api.gofundraise.com.au/v1/leaderboards/fundraising?EventCampaignId=$event_id";
    $url .= "&Mode=".ucfirst($mode);

    // TODO:
    // - get all charities of this event.

    // - so after that all will be good.

//    $url = 'https://api.gofundraise.com.au/v1/leaderboards/fundraising?';
//    $url .= 'EventCampaignId=' . $event_id;
//    if ($bene_id) $url .= '&BeneficiaryAccountId=' . $bene_id;
//    if (strtolower($mode)=='individual'||strtolower($mode)=='team') $url .= "&Mode=".ucfirst($mode);
//    if ($size) $url .= "&Size=$size";
//    else {
//        $page_type = 'S';
//        if (strtolower($mode)=='team') {
//            $page_type = 'T';
//        }
//        $url .= "&Size=" .get_count($event_id,$bene_id,$page_type,'AU');
//    }
    // --------------------------------------
    $response = wp_remote_get($url);
    if (is_wp_error($response)) return array();
    $body = json_decode($response['body']);
    if (!isset($body->Leaderboard)) return array();

    return array_map(function($item) use ($region, $charity) {
        $item->region = $region;
        $item->name = $item->FirstName . ' ' . $item->LastName;
        $item->charity = (object) $charity;
        return $item;
    }, $body->Leaderboard);
}

function check_expired_cache_time ($cachefile) {
    if (file_exists($cachefile) && (time() - CACHE_TIME < filemtime($cachefile)) ) {
        return false;
    }
    return true;
}

function create_cache_files ($cachefile, $data) {
    $cached = fopen($cachefile, 'w');
    fwrite($cached, $data);
    fclose($cached);
}

// Format event id
function format_events ($event_data) {
    $raw_event_ids = explode(',',$event_data);
    return array_filter($raw_event_ids, function ($item){
        return is_numeric($item);
    });
}

function check_attr($name, $array) {
    if (is_array($array) && array_key_exists($name, $array) && $array[$name]) return true;
    return false;
}

