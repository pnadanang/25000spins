jQuery(function($){
    // WP Frank
    $('a[href="https://www.wpfrank.com/"]').parent().hide();
})
