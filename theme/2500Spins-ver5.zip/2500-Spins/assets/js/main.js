jQuery(function($) {

    // =============================
    setInterval(function(){
        // =============================
        var maxHeight_slider = 0;
        var video_box = jQuery('.video-box-homepage').parent('.owl-item');
        $(video_box).each(function(){
            if ($(this).height() > maxHeight_slider) { maxHeight_slider = $(this).height(); }
        });
        $("#slider_home .big .owl-item").height(maxHeight_slider);
// ====================================
        // $("#slider_home .big .owl-item").css('max-height','400px');
        // $("#slider_home .et_pb_video_box video").css('height','600px!important');
        // ====================================
    }, 100);
// ========================================
    setTimeout(function(){
        $('.full_width_3_col.center span.number').each(function() {
            $(this).prop('Counter', 0).animate({
                Counter: $(this).html()
            }, {
                duration: 6000,
                easing: 'swing',
                step: function(now) {
                    $(this).text(Math.ceil(now).toLocaleString('en'));
                }
            });
        });
// ========================================
    }, 2000);

    // ------------------------------------------------------------
 // (function( $ ){
 //  var filterObj = function(){
    var requestdata ={
      'term':'',
      'region':'',
      'cylce':'',
      'price':''
    };
    //term
    var term = $("#termiput").val();
    requestdata.term =term;
    //Regions
    var region = $(".regions-filter .input-filter input");
    region.on("click",function(){
      var regiondata = [];
        $.each(region,function(index,value){
        var $this = $(value);
        if($this.is(":checked")){
         regiondata.push($this.val());
        }
        })
      requestdata.region=regiondata;
      console.log(requestdata);
      ajax_request();
    })
  //CYLCE TYPE
  var cylce_type = $(".cylcetype-filter .input-filter input");
      cylce_type.on("click",function(){
        var cylce_typedata = [];
          $.each(cylce_type,function(index,value){
          var $this = $(value);
          if($this.is(":checked")){
           cylce_typedata.push($this.val());
          }
          })
        requestdata.cylce=cylce_typedata;
      console.log(requestdata);
      ajax_request();
      })
//PRICE

    // var pricemin = $(".price-filter .input-filter .irs-handle.from,.price-filter .input-filter .irs-handle.to");
    //       $(document).on("mouseout",pricemin,function(){
    //        var price = [];
    //         let min = $(".price-filter .min_price .label_price").text();
    //         let max = $(".price-filter .max_price .label_price").text();

    //       price.push(min);
    //       price.push(max);
    //     console.log(price);
    //   })


 function ajax_request(){
  $.ajax({
      url: mainjs_ajax_object.ajax_url,
      type: "POST",
      data:{
        requestdata: requestdata,
        action: "process_data_ajax"
      },
      success: function(data){
       $(".result-data").html(data);
      },
      error: function(error){
        console.log("fail");
      }
    })
 }
// }
// jQuery(document).ready(function($){
// var compon =  new filterObj();
// })
// })( jQuery );

// $(".footer-right .social_footer").append($("#custom_html-6"));
// ===============================
// console.log(123);
    $('.filter-widget-box h4').click(function(){
      $(this).next('.filter-wrapper').slideToggle(500);
      $(this).toggleClass('close');
    });
    // ==============================
    $(".filter-widget-box input[type='checkbox']").click( function(){
       if( $(this).is(':checked') ) {
          $(this).parent('label').addClass('checked');
       }else{
          $(this).parent('label').removeClass('checked');
       }
    });
    // ===================================
    var minValue= $('.range-slider-price[type="range"]').prop('min');
    var maxValue = $('.range-slider-price[type="range"]').prop('max');
    $(".range-slider-price").ionRangeSlider({
        skin: "round",
        type: "double",
        grid: false,
        min: minValue,
        max: maxValue,
        from: minValue,
        to: maxValue,
        // prefix: "$",
    });
    $(".range-slider-price").on("change", function () {
        var $inp = $(this);
        // var v = $inp.prop("value");     // input value in format FROM;TO
        var from = $inp.data("from");   // input data-from attribute
        var to = $inp.data("to");       // input data-to attribute
        $('.min_price span.label_price').text('$ ' +from);
        $('.max_price span.label_price').text('$ ' +to);
        // console.log(v, from, to);       // all values
         // console.log(from, to);
         var price = [];
         price.push(from);
        price.push(to);
        requestdata.price = price;
        ajax_request();
    });
// ============================================================
    $('#menu_responsive ul#menu-primary-menu > li.menu-item-has-children > a').click(function(e){
        $(this).next('ul.sub-menu').slideToggle();
        $(this).parent('li').toggleClass('open-child');
        e.preventDefault();
    });
    $('#menu_responsive ul#menu-secondary-menu > li.menu-item-has-children > a').click(function(e){
        $(this).next('ul.sub-menu').slideToggle();
        $(this).parent('li').toggleClass('open-child');
        e.preventDefault();
    });
    $('ul li.search-items-icon a').click(function(e){
        $('.form-box').slideToggle(300);
        e.preventDefault();
    });
    $('.form-box .close-form').click(function(e){
        $('.form-box').hide(200);
        e.preventDefault();
    });
    $('#search_responsive_bar i.fa-search').click(function(e){
        $('.search_responsive_box').slideToggle(300);
        e.preventDefault();
    });
// ================REMOVE $ SPECIAL CHARACTER========================
    var string = $('.find-adventure span.raise-so-far-donate-count').html();
    var string_change = '';
    if (string)
        string_change = string.replace("$", "");
    // var string_change = Math.ceil(string_change);
    $('.find-adventure span.raise-so-far-donate-count').html(string_change);
// ================REMOVE , and . SPECIAL CHARACTER AND ANIMATION NUMBER========================
    var string_2 = $('.full_width_3_col.center span.raise-so-far-donate-count').html();

    var string_change_2 = string_2 ? string_2.replace(',','').replace('$','') : "";
    var string_change_2 = Math.ceil(string_change_2)
    $('.full_width_3_col.center span.raise-so-far-donate-count').html(string_change_2);

    $('.full_width_3_col.center span.raise-so-far-donate-count').each(function() {
         $(this).prop('Counter', 0).animate({
            Counter: $(this).html()
         }, {
            duration: 8000,
            easing: 'swing',
            step: function(now) {
               $(this).text(Math.ceil(now).toLocaleString('en'));
            }
         });
    });

// ========================================
  $('#menu_responsive_bar i').click(function(){
      $('#menu_responsive').slideToggle(500);
  });
// console.log(1);
  window.onscroll = function() {myFunction()};
  var header = document.getElementById("scroll-nav"),
      sticky = header.offsetTop,
      top_menu = $('#top_menu'),
      logo_container = top_menu.children('.logo_container'),
      main_menu_wrapper = $('#main_menu_wrapper'),
      primary_menu = main_menu_wrapper.find('.primary_menu');
  function myFunction() {
    var logo_width = logo_container.width(),
      menu_height = main_menu_wrapper.height();
    if (window.pageYOffset > sticky) {
        header.classList.add("sticky");
        logo_container.css({
        'height': menu_height,
        'width': logo_width
      });
        primary_menu.css('padding-left', logo_width);
    } else {
      header.classList.remove("sticky");
        logo_container.css({'height': ''});
        primary_menu.css('padding-left', '');
    }
  }
  // ============================================
 });

